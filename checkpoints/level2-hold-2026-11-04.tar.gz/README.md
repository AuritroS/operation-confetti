# Operation Confetti

A short portrait-only browser game for Matthew's birthday. Guests scan a QR
code, enter a display name, play three levels, and land on a leaderboard.

Design doc: [`design.md`](./design.md) · Settled tech spec: [`docs/TECH_SPEC.md`](./docs/TECH_SPEC.md)

- **Stack:** Vite + TypeScript + Three.js, plain HTML/CSS overlays
- **Hosting:** Cloudflare Worker serving static assets *and* the score API,
  on `operation-confetti.auritro.com`
- **Data:** Supabase Postgres, reached only from the Worker

## Current review: level 2 — 3D left/right control trial

The game opens directly in **Skyline Chase** at `/` (also `/?level=2`).
Level 1 remains frozen and separately accessible at `/?level=1`.

Hold the **left or right half of the playfield** to catch the highlighted
anchor on that side. Desktop: hold **A/D** or **left/right arrow**. Release
to fly; press again for the next swing. The side is chosen when the press
starts, so dragging across the middle does not change anchors. One finger
controls one rope. The first swing waits for input.

Attachment distance determines rope length. The rope stays fixed for the
swing; release timing determines the flight into the next attachment.
The character travels in three dimensions between buildings, with a camera
following behind. Forward and lateral assistance keep the short course
forgiving. This is a primitive gameplay trial, with final character/city art
still to follow. Automatic side selection is deliberately deferred until
this control scheme has been reviewed.

**Replay / R** restarts, **P** pauses, **I** toggles debug (`?debug` starts
with it visible). Pausing preserves the rope. Falls and collisions freeze
movement: lift, then hold either side to reattach and rise continuously
from the failure position. The route is 360 units, about 23–29 seconds on
the tested paths, with one teaching gift, four scored gifts at different
heights, a low obstacle and an overhead bridge. Gifts give +100, incidents
−50, and reaching the end gives +200.

`npm run check:swing` builds an isolated review bundle and checks real
left/right touch and keyboard controls, cancellation, pause, replay,
recovery, a full route, and six viewport sizes in Chromium. It serves local
files through Playwright interception, so it needs no running web server.
Screenshots land in `tools/shots/level2-3d-*.png`. The tested route peaks at
37 draw calls and 5,488 triangles; this is a rendering workload measurement,
not a phone frame-rate benchmark.

Current implementation: `src/levels/chase.ts`, `src/core/chase-input.ts`,
`src/render/chase-scene.ts`, and `src/level2.ts`. Earlier planar swing files
remain as reference and are not imported by the current level 2 entry.
See [`design-level2.md`](./design-level2.md) for the recovered plan and review history.

---

## First-time setup

```bash
# 1. Dependencies
npm install

# 2. Secrets
cp .env.example .env            # fill in SUPABASE_DB_PASSWORD + the API keys
cp .dev.vars.example .dev.vars  # fill in SUPABASE_SERVICE_ROLE_KEY

# 3. Database
npm run db:push                 # applies supabase/schema.sql
npm run db:check                # confirms tables exist

# 4. Stage runtime assets into public/
npm run assets:build
```

`.env`, `.dev.vars` and `supabase.txt` are gitignored. The service-role key
belongs only in `.dev.vars` and in `wrangler secret`; it must never reach the
browser bundle.

## Daily development

```bash
npm run worker:dev   # terminal 1 — Worker + API on :8787
npm run dev          # terminal 2 — Vite on :5173, proxies /api to the Worker
```

Three pages in dev:

| Path | What it is |
|---|---|
| `/` | the game |
| `/assets` | asset gallery — browse all 120 models, pick the ones to use |
| `/probe.html` | character harness — play any clip, attach props |

The gallery needs an index first:

```bash
npm run assets:index   # writes .asset-index.json
```

It is a **development tool only**. The source packs are 42 MB, so they are
streamed off disk by a dev-only Vite plugin rather than copied into `public/`,
which would inflate the deployed game from 2.9 MB to nearly 45 MB. `/assets`
is therefore not part of `npm run build`.

### Desktop controls

| Key | Action |
|---|---|
| `←` `→` or `A` `D` | Move one lane |
| `Space` | Tap (short press) or hold/release (level 2 grapple) |
| `P` or `Esc` | Pause / resume |
| `R` | Restart the run |

`W`, `S` and the vertical arrows are claimed so the page cannot scroll, but do
nothing — no level has a forward or backward axis. Gameplay keys are ignored
while a text field has focus, so name entry types normally.

### Testing on a phone

`npm run dev` binds loopback only. To reach it from your phone, serve it over
your tailnet:

```bash
npm run dev            # terminal 1
npm run tunnel         # terminal 2 — prints the https://<host>.ts.net URL
npm run tunnel -- off  # tear down when finished
```

This goes over **HTTPS on purpose**, not the raw `100.x` address: a plain
`http://` origin is not a secure context, so `crypto.randomUUID` — which mints
run and player IDs — is undefined there and the phone test would diverge from
production. `tailscale serve` terminates TLS with a real cert for the tailnet
name. It needs MagicDNS and HTTPS certificates enabled in the Tailscale admin
console (DNS section).

`npm run dev:lan` binds `0.0.0.0` instead, if you would rather use the plain
LAN address and accept the insecure-context caveat.

### Headless visual check

```bash
npm run shoot -- http://127.0.0.1:5173/?clean --out game --wait 3500
```

Loads the page in headless Chromium, captures a screenshot to `tools/shots/`,
and reports the HUD, the debug panel, every console error, whether the page
scrolls, and whether anything full-screen and interactive sits above the input
surface — the bug class that once made the game unresponsive on a phone for
two rounds.

`?clean` hides the debug panel so the shot shows only what a player sees.

Two constraints worth knowing. It passes `--single-process`: Chromium's
multi-process model registers a Mach bootstrap port to rendezvous with its
renderers, and the Bash sandbox denies `bootstrap_check_in`, so the browser
dies at launch without it. And it renders through SwiftShader, which is a real
WebGL 2.0 context but not a phone GPU — this catches breakage, never feel.

## Checks

```bash
npm run typecheck        # tsc, no emit
npm test                 # scoring, lane and gesture checks
npm run assets:inspect   # real GLB metrics: triangles, clips, attachments
```

Current measured cold transfer, pre-compression: **2.9 MB** — 1.9 MB
characters and animation libraries, 428 KB story panels, 604 KB JS/CSS
(≈140 KB gzipped). Targets are 5 MB total and 500 KB compressed JS/CSS.

## Deploy

```bash
wrangler login
wrangler secret put SUPABASE_URL
wrangler secret put SUPABASE_SERVICE_ROLE_KEY
npm run deploy
```

The custom domain in `wrangler.toml` requires `auritro.com` to be an active
zone on the same Cloudflare account; Wrangler creates the DNS record.

## Layout

```
src/core/      loop, input recogniser, lanes, lifecycle, scoring (pure)
src/render/    renderer and camera
src/assets/    manifest (pinned versions + clip map), character loader
src/ui/        HUD and overlays
src/net/       score client with offline retry
worker/        Cloudflare Worker: static host + /api
supabase/      schema.sql
tools/         asset inspection, asset staging, stripping, db push, tunnel
tests/         focused automated checks
assets/        pinned CC0 source packs (committed on purpose)
```

## Licensing

All three source packs are CC0: KayKit Adventurers 2.0, KayKit City Builder
Bits 1.0, Kenney Blaster Kit 2.1. Attribution is optional but intended —
"Kay Lousberg (kaylousberg.com)" and "Kenney (kenney.nl)". The `License.txt`
of each pack is kept in place under `assets/`.
