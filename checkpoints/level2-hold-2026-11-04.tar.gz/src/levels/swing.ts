import type { RunEvent } from '../core/scoring';
import type { SwingAnchor, SwingConfig, SwingMode, SwingPoint, SwingSnapshot } from './swing-types';

const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
const SUBSTEP = 1 / 240;
const PLAYER_HALF_Z = 0.35;
const PLAYER_HALF_Y = 0.65;

/** Slab test in (z,y); expand the box by the player's half extents first. */
export function segmentHitsBox(from: SwingPoint, to: SwingPoint, box: SwingPoint, halfZ: number, halfY: number): boolean {
  let near = 0;
  let far = 1;
  for (const [p, delta, centre, half] of [
    [from.z, to.z - from.z, box.z, halfZ],
    [from.y, to.y - from.y, box.y, halfY],
  ] as const) {
    if (Math.abs(delta) < 1e-12) {
      if (p < centre - half || p > centre + half) return false;
      continue;
    }
    const a = (centre - half - p) / delta;
    const b = (centre + half - p) / delta;
    near = Math.max(near, Math.min(a, b));
    far = Math.min(far, Math.max(a, b));
    if (near > far) return false;
  }
  return true;
}

/**
 * Pure, fixed-step swing simulation. No DOM, three.js or level 1 dependency.
 * Attached motion has ONE degree of freedom: angle about a fixed anchor.
 * Gravity changes tangent speed; a small floor supplies the arcade stall
 * assist. The forward velocity floor applies only while detached.
 */
export class SwingRunner {
  private z: number;
  private y: number;
  private vz: number;
  private vy = 0;
  private mode: SwingMode = 'detached';
  private held = false;
  private requiresRelease = false;
  private anchor: SwingAnchor | null = null;
  private radius = 0;
  private angle = 0;
  private startAngle = 0;
  private tangentSpeed = 0;
  private elapsed = 0;
  private swings = 0;
  private lastAttachTime: number | null = null;
  private lastCycle = 0;
  private recoveries = 0;
  private failure: SwingSnapshot['failure'] = null;
  private recoveryAnchor: SwingAnchor | null = null;
  private incidents = 0;
  private protection = 0;
  private releases = 0;
  private lastRelease: SwingSnapshot['lastRelease'] = null;
  private readonly usedAnchors = new Set<string>();
  readonly entityStates = new Map<string, 'collected' | 'hit' | 'missed'>();
  readonly events: RunEvent[] = [];
  private listener: (event: RunEvent) => void = () => {};

  constructor(readonly config: SwingConfig) {
    this.z = config.start.z;
    this.y = config.start.y;
    this.vz = config.forwardFloor;
  }

  onEvent(listener: (event: RunEvent) => void): void { this.listener = listener; }

  get isComplete(): boolean { return this.mode === 'complete'; }
  get isFrozen(): boolean { return this.mode === 'recovery'; }

  get snapshot(): SwingSnapshot {
    return {
      z: this.z, y: this.y, vz: this.vz, vy: this.vy,
      mode: this.mode, held: this.held, requiresRelease: this.requiresRelease,
      anchor: this.anchor, eligible: this.nextAnchor(), radius: this.radius, angle: this.angle,
      speed: Math.hypot(this.vz, this.vy), progress: this.z / this.config.routeLength,
      complete: this.mode === 'complete', elapsed: this.elapsed, swings: this.swings,
      lastCycle: this.lastCycle, recoveries: this.recoveries, failure: this.failure, incidents: this.incidents,
      invulnerable: this.protection > 0, releases: this.releases, lastRelease: this.lastRelease,
    };
  }

  /** The highlighted anchor and the attached anchor always use this rule. */
  private nextAnchor(): SwingAnchor | null {
    if (this.mode === 'recovery') return this.recoveryAnchor;
    if (this.anchor || this.requiresRelease || this.mode === 'complete') return null;
    const c = this.config;
    return this.config.anchors.find((a) => {
      const lead = a.z - this.z;
      const rise = a.y - this.y;
      const distance = Math.hypot(lead, rise);
      return !this.usedAnchors.has(a.id) && lead >= c.minLead && lead <= c.maxLead &&
        rise >= 1 && distance >= c.minRope && distance <= Math.min(c.maxRope, a.y - c.floor - 1.2);
    }) ?? null;
  }

  holdStart(): void {
    if (this.mode === 'complete' || this.held) return;
    this.held = true;
    // A fresh press after pausing re-grips the preserved rope.
    if (this.anchor || this.requiresRelease) return;
    if (this.mode === 'recovery' && this.recoveryAnchor) {
      this.attach(this.recoveryAnchor);
      this.mode = 'recovering';
      this.vz = 0;
      this.vy = this.radius > this.config.minRope ? 22 : 0;
      // Protection covers the lift and the first normal arc. Hit entities
      // are resolved permanently, so they can never charge again.
      this.protection = 2;
      return;
    }
    const next = this.nextAnchor();
    if (next) this.attach(next);
    else this.mode = 'armed';
  }

  holdEnd(): void {
    if (this.mode === 'complete') return;
    this.held = false;
    if (this.anchor) this.release('manual');
    this.requiresRelease = false;
    if (this.mode === 'armed') this.mode = 'detached';
  }

  cancelHold(): void {
    if (this.mode === 'complete') return;
    this.held = false;
    if (this.anchor) this.release('cancel');
    this.requiresRelease = false;
    if (this.mode === 'armed') this.mode = 'detached';
  }

  /** Pause clears the physical hold, not the rope, position or velocities. */
  pauseHold(): void {
    this.held = false;
    this.requiresRelease = false;
    if (this.mode === 'armed') this.mode = 'detached';
  }

  private attach(anchor: SwingAnchor): void {
    const dz = this.z - anchor.z;
    const drop = anchor.y - this.y;
    this.radius = Math.hypot(dz, drop);
    this.angle = Math.atan2(dz, drop);
    this.startAngle = this.angle;
    // Project incoming momentum onto the tangent; there is no position snap.
    this.tangentSpeed = clamp(this.vz * Math.cos(this.angle) + this.vy * Math.sin(this.angle),
      this.config.minAttachSpeed, this.config.maxSwingSpeed);
    this.anchor = anchor;
    this.usedAnchors.add(anchor.id);
    this.mode = 'swinging';
    this.swings++;
    if (this.lastAttachTime !== null) this.lastCycle = this.elapsed - this.lastAttachTime;
    this.lastAttachTime = this.elapsed;
    this.setTangentVelocity();
  }

  private setTangentVelocity(): void {
    this.vz = this.tangentSpeed * Math.cos(this.angle);
    this.vy = this.tangentSpeed * Math.sin(this.angle);
  }

  private release(reason: 'manual' | 'auto' | 'cancel'): void {
    if (this.mode === 'recovering') {
      // Releasing during the safety lift still launches upward; no snap.
      this.vz = Math.max(this.vz, this.config.forwardFloor * 0.6);
      this.vy = Math.max(this.vy, 16);
    }
    this.anchor = null;
    this.mode = 'ballistic';
    this.requiresRelease = this.held;
    this.lastRelease = reason;
    this.recoveryAnchor = null;
    this.releases++;
    // Keep the tangent velocity intact here. Airborne assistance ramps it
    // toward the floor on subsequent steps instead of injecting a jump.
  }

  update(step: number): void {
    if (this.isComplete || this.isFrozen || !Number.isFinite(step) || step <= 0) return;
    // Curved arcs are split into short chords for swept collision checks.
    const count = Math.ceil(step / SUBSTEP);
    const dt = step / count;
    for (let i = 0; i < count && !this.isComplete && !this.isFrozen; i++) this.advance(dt);
  }

  private advance(dt: number): void {
    const c = this.config;
    this.elapsed += dt;
    if (this.mode !== 'recovering') this.protection = Math.max(0, this.protection - dt);
    if (this.mode === 'armed') {
      const next = this.nextAnchor();
      if (next) this.attach(next);
    }
    const from = { z: this.z, y: this.y };
    if (this.mode === 'recovering' && this.anchor) {
      // A recovery anchor is directly overhead. Reeling up is continuous,
      // keeps z unchanged, and never sweeps scoring contacts on the way up.
      // At the normal radius, hand back to the same pendulum controller.
      const lift = Math.min(22 * dt, this.radius - c.minRope);
      this.radius -= lift;
      this.y += lift;
      this.vy = lift / dt;
      if (this.radius <= c.minRope + 1e-8) {
        this.mode = 'swinging';
        this.angle = 0;
        this.startAngle = 0;
        this.setTangentVelocity();
      }
      return;
    } else if (this.anchor) {
      this.tangentSpeed = clamp(this.tangentSpeed - c.gravity * Math.sin(this.angle) * dt,
        c.minSwingSpeed, c.maxSwingSpeed);
      const ceilingAngle = Math.acos(clamp((this.anchor.y - c.ceiling) / this.radius, -1, 1));
      const endAngle = Math.min(c.releaseAngle, this.startAngle + c.maxSweep, ceilingAngle);
      this.angle = Math.min(endAngle, this.angle + this.tangentSpeed / this.radius * dt);
      this.z = this.anchor.z + this.radius * Math.sin(this.angle);
      this.y = this.anchor.y - this.radius * Math.cos(this.angle);
      this.setTangentVelocity();
      if (this.angle >= endAngle) this.release('auto');
    } else {
      // Bounded acceleration preserves release direction and rewards speed.
      if (this.vz < c.forwardFloor) this.vz = Math.min(c.forwardFloor, this.vz + 20 * dt);
      this.vz = Math.min(c.forwardCeiling, this.vz);
      this.vy = Math.max(-c.maxSwingSpeed, this.vy - c.gravity * dt);
      this.z += this.vz * dt;
      this.y += this.vy * dt;
      if (this.y > c.ceiling) { this.y = c.ceiling; this.vy = Math.min(0, this.vy); }
    }
    const belowFloor = this.y < c.floor;
    if (belowFloor) {
      // Stop at the crossing itself. There is no route skip or teleport.
      const fraction = clamp((from.y - c.floor) / (from.y - this.y), 0, 1);
      this.z = from.z + (this.z - from.z) * fraction;
      this.y = c.floor;
    }
    this.resolveContacts(from);
    if (this.isFrozen) return;
    if (belowFloor) { this.freeze('fall'); return; }
    if (this.z >= c.routeLength) {
      this.z = c.routeLength;
      this.anchor = null;
      this.mode = 'complete';
      this.held = false;
      this.emit({ t: 'routeComplete', level: 2 });
    }
  }

  private resolveContacts(from: SwingPoint): void {
    for (const e of this.config.entities) {
      if (this.entityStates.has(e.id)) continue;
      if (segmentHitsBox(from, { z: this.z, y: this.y }, e, e.halfZ + PLAYER_HALF_Z, e.halfY + PLAYER_HALF_Y)) {
        this.entityStates.set(e.id, e.kind === 'gift' ? 'collected' : 'hit');
        if (e.kind === 'gift') {
          if (e.scored) this.emit({ t: 'gift', level: 2 });
        } else if (this.protection <= 0) {
          this.freeze('hazard');
          return;
        }
      } else if (this.z > e.z + e.halfZ + PLAYER_HALF_Z) this.entityStates.set(e.id, 'missed');
    }
  }

  private billIncident(): void {
    this.incidents++;
    this.emit({ t: 'incident', level: 2 });
  }

  private freeze(reason: 'fall' | 'hazard'): void {
    if (this.isFrozen || this.isComplete) return;
    this.billIncident();
    this.recoveries++;
    this.failure = reason;
    this.vz = 0;
    this.vy = 0;
    this.anchor = null;
    this.mode = 'recovery';
    this.requiresRelease = this.held;
    // Always reachable, even with no normal anchor ahead. The player stays
    // exactly where they failed. A fresh hold reels up before swinging on.
    this.recoveryAnchor = {
      id: `recovery-${this.recoveries}`, z: this.z,
      y: Math.max(12, this.y + this.config.minRope),
    };
  }

  private emit(event: RunEvent): void { this.events.push(event); this.listener(event); }
}
