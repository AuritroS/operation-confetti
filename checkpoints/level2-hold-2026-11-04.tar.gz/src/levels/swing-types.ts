/** Gameplay coordinates: z increases along the route, y is height, x is fixed. */
export interface SwingPoint { readonly z: number; readonly y: number }
export interface SwingAnchor extends SwingPoint { readonly id: string }
export interface SwingEntity extends SwingPoint {
  readonly id: string;
  readonly kind: 'gift' | 'hazard';
  readonly halfZ: number;
  readonly halfY: number;
  readonly scored: boolean;
}
export interface SwingConfig {
  readonly routeLength: number;
  readonly gravity: number;
  readonly forwardFloor: number;
  readonly forwardCeiling: number;
  readonly minSwingSpeed: number;
  readonly minAttachSpeed: number;
  readonly maxSwingSpeed: number;
  readonly minRope: number;
  readonly maxRope: number;
  readonly minLead: number;
  readonly maxLead: number;
  readonly releaseAngle: number;
  readonly maxSweep: number;
  readonly ceiling: number;
  readonly floor: number;
  readonly start: SwingPoint;
  readonly anchors: readonly SwingAnchor[];
  readonly entities: readonly SwingEntity[];
}
export type SwingMode = 'detached' | 'armed' | 'swinging' | 'ballistic' | 'recovery' | 'recovering' | 'complete';
export interface SwingSnapshot extends SwingPoint {
  readonly vz: number;
  readonly vy: number;
  readonly mode: SwingMode;
  readonly held: boolean;
  readonly requiresRelease: boolean;
  readonly anchor: SwingAnchor | null;
  readonly eligible: SwingAnchor | null;
  readonly radius: number;
  readonly angle: number;
  readonly speed: number;
  readonly progress: number;
  readonly complete: boolean;
  readonly elapsed: number;
  readonly swings: number;
  readonly lastCycle: number;
  readonly recoveries: number;
  readonly failure: 'fall' | 'hazard' | null;
  readonly incidents: number;
  readonly invulnerable: boolean;
  readonly releases: number;
  readonly lastRelease: 'manual' | 'auto' | 'cancel' | null;
}
