import type { SwingConfig } from './swing-types';

/** Wider review route. Heights and contact bounds also drive the visuals. */
export const LEVEL_2_PRACTICE: SwingConfig = {
  routeLength: 1150,
  gravity: 24,
  forwardFloor: 13,
  forwardCeiling: 20,
  minSwingSpeed: 9,
  minAttachSpeed: 12,
  maxSwingSpeed: 26,
  minRope: 8,
  maxRope: 20,
  minLead: 3,
  maxLead: 18,
  releaseAngle: Math.PI / 3,
  maxSweep: Math.PI * 5 / 6,
  ceiling: 24,
  floor: -12,
  start: { z: 0, y: 5 },
  anchors: Array.from({ length: 46 }, (_, i) => ({
    id: `a${i}`, z: 15 + Math.floor(i / 3) * 78 + [0, 24, 50][i % 3]!, y: 12,
  })),
  entities: [
    { id: 'teach', kind: 'gift', z: 20, y: -3.5, halfZ: 0.7, halfY: 0.7, scored: false },
    { id: 'g1', kind: 'gift', z: 80, y: 1, halfZ: 0.7, halfY: 0.7, scored: true },
    { id: 'low1', kind: 'hazard', z: 125, y: -8.5, halfZ: 1.4, halfY: 2.3, scored: false },
    { id: 'high1', kind: 'hazard', z: 260, y: 6, halfZ: 1.8, halfY: 2.5, scored: false },
    { id: 'g2', kind: 'gift', z: 360, y: 2, halfZ: 0.7, halfY: 0.7, scored: true },
    { id: 'low2', kind: 'hazard', z: 560, y: -8.5, halfZ: 1.4, halfY: 2.3, scored: false },
    { id: 'g3', kind: 'gift', z: 620, y: -2, halfZ: 0.7, halfY: 0.7, scored: true },
    { id: 'high2', kind: 'hazard', z: 880, y: 3.5, halfZ: 1.8, halfY: 2.5, scored: false },
    { id: 'g4', kind: 'gift', z: 980, y: -1, halfZ: 0.7, halfY: 0.7, scored: true },
  ],
};
