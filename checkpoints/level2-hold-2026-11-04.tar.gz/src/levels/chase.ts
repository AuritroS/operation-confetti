import type { RunEvent } from '../core/scoring';

export type Side = 'left' | 'right';
export interface Point3 { x: number; y: number; z: number }
export interface ChaseAnchor extends Point3 { id: string; side: Side }
export interface ChaseEntity extends Point3 {
  id: string; kind: 'gift' | 'hazard'; halfX: number; halfY: number; halfZ: number; scored: boolean;
}
export interface ChaseConfig {
  start: Point3; routeLength: number; floor: number; wall: number;
  anchors: ChaseAnchor[]; entities: ChaseEntity[];
}
export const CHASE: ChaseConfig = {
  start: { x: 0, y: 6, z: 0 }, routeLength: 360, floor: -16, wall: 12,
  anchors: Array.from({ length: 16 }, (_, i) => (['left', 'right'] as const).map((side) => ({
    id: `${side}-${i}`, side, x: side === 'left' ? -8 : 8,
    y: 15 + (i % 3 === 1 ? 2 : 0), z: 18 + i * 26,
  }))).flat(),
  entities: [
    { id: 'teach', kind: 'gift', x: -2.6, y: -5.6, z: 14, halfX: 1.2, halfY: 1.2, halfZ: 1.2, scored: false },
    { id: 'g1', kind: 'gift', x: 5, y: -1.5, z: 65, halfX: 1.2, halfY: 1.2, halfZ: 1.2, scored: true },
    { id: 'roof', kind: 'hazard', x: -5, y: -8, z: 115, halfX: 5, halfY: 3, halfZ: 2.5, scored: false },
    { id: 'g2', kind: 'gift', x: -7.5, y: 5.5, z: 144, halfX: 1.2, halfY: 1.2, halfZ: 1.2, scored: true },
    { id: 'bridge', kind: 'hazard', x: 0, y: 4, z: 208, halfX: 12, halfY: 1.5, halfZ: 2, scored: false },
    { id: 'g3', kind: 'gift', x: -3, y: -1, z: 240, halfX: 1.2, halfY: 1.2, halfZ: 1.2, scored: true },
    { id: 'g4', kind: 'gift', x: 6.5, y: 5, z: 320, halfX: 1.2, halfY: 1.2, halfZ: 1.2, scored: true },
  ],
};

export type ChaseMode = 'ready' | 'detached' | 'armed' | 'swinging' | 'ballistic' | 'recovery' | 'recovering' | 'complete';
export interface ChaseSnapshot extends Point3 {
  vx: number; vy: number; vz: number; mode: ChaseMode; held: boolean; side: Side | null;
  requiresRelease: boolean; anchor: ChaseAnchor | null;
  targets: Record<Side, ChaseAnchor | null>; radius: number; elapsed: number; swings: number;
  recoveries: number; complete: boolean; speed: number; progress: number;
  lastRelease: 'manual' | 'auto' | 'cancel' | null;
}

/** Continuous collision in all three axes, including high-speed gift passes. */
export function hits3(from: Point3, to: Point3, box: ChaseEntity): boolean {
  let near = 0, far = 1;
  for (const [axis, half] of [['x', box.halfX + 0.4], ['y', box.halfY + 0.75], ['z', box.halfZ + 0.4]] as const) {
    const delta = to[axis] - from[axis];
    if (Math.abs(delta) < 1e-12) {
      if (Math.abs(from[axis] - box[axis]) > half) return false;
    } else {
      const a = (box[axis] - half - from[axis]) / delta;
      const b = (box[axis] + half - from[axis]) / delta;
      near = Math.max(near, Math.min(a, b)); far = Math.min(far, Math.max(a, b));
      if (near > far) return false;
    }
  }
  return true;
}

/** Independent 3D point-mass tether. Input chooses a side; physics only needs an anchor. */
export class ChaseRunner {
  private p: Point3;
  private v: Point3 = { x: 0, y: 0, z: 18 };
  private mode: ChaseMode = 'ready';
  private held = false;
  private side: Side | null = null;
  private requiresRelease = false;
  private anchor: ChaseAnchor | null = null;
  private radius = 0;
  private elapsed = 0;
  private swings = 0;
  private recoveries = 0;
  private protection = 0;
  private lastRelease: ChaseSnapshot['lastRelease'] = null;
  private used = new Set<string>();
  readonly entityStates = new Map<string, 'collected' | 'hit' | 'missed'>();
  readonly events: RunEvent[] = [];
  private listener: (e: RunEvent) => void = () => {};
  constructor(readonly config: ChaseConfig = CHASE) { this.p = { ...config.start }; }
  onEvent(listener: (e: RunEvent) => void): void { this.listener = listener; }
  private emit(e: RunEvent): void { this.events.push(e); this.listener(e); }
  get snapshot(): ChaseSnapshot {
    return { ...this.p, vx: this.v.x, vy: this.v.y, vz: this.v.z, mode: this.mode,
      held: this.held, side: this.side, requiresRelease: this.requiresRelease, anchor: this.anchor,
      targets: { left: this.target('left'), right: this.target('right') }, radius: this.radius,
      elapsed: this.elapsed, swings: this.swings, recoveries: this.recoveries,
      complete: this.mode === 'complete', speed: Math.hypot(this.v.x, this.v.y, this.v.z),
      progress: this.p.z / this.config.routeLength, lastRelease: this.lastRelease };
  }
  private target(side: Side): ChaseAnchor | null {
    if (this.mode === 'recovery') return { id: 'rescue', side, x: this.p.x, y: Math.max(14, this.p.y + 8), z: this.p.z };
    if (this.anchor || this.requiresRelease || this.mode === 'complete') return null;
    return this.config.anchors.find((a) => {
      const length = Math.hypot(a.x - this.p.x, a.y - this.p.y, a.z - this.p.z);
      return a.side === side && !this.used.has(a.id) && a.z - this.p.z >= 2 && a.z - this.p.z <= 25 &&
        a.y > this.p.y + 1 && length >= 6 && length <= 29;
    }) ?? null;
  }
  holdStart(side: Side): void {
    if (this.held || this.mode === 'complete') return;
    this.held = true; this.side = side;
    if (this.anchor || this.requiresRelease) return;
    const a = this.target(side);
    const recovery = this.mode === 'recovery';
    if (!a) { this.mode = 'armed'; return; }
    this.anchor = a;
    this.radius = Math.hypot(this.p.x - a.x, this.p.y - a.y, this.p.z - a.z);
    this.used.add(a.id); this.swings++;
    if (recovery) { this.mode = 'recovering'; this.protection = 2; return; }
    this.mode = 'swinging';
    // A small launch assist makes the chosen side immediately legible. Without
    // it, projecting purely forward velocity onto a long, forward-facing rope
    // initially sends the player away from the selected side.
    this.v.x += Math.sign(a.x - this.p.x) * (this.swings === 1 ? 8 : 5);
    if (this.swings === 1) this.v.y = Math.min(this.v.y, -4);
    this.tangent();
    const speed = Math.hypot(this.v.x, this.v.y, this.v.z);
    if (speed < 17) {
      // Forward assistance lies on the rope tangent; attachment never moves the character.
      const scale = 17 / Math.max(1, Math.hypot(this.v.x, this.v.y, this.v.z));
      this.v.x *= scale; this.v.y *= scale; this.v.z *= scale;
    }
  }
  holdEnd(reason: 'manual' | 'cancel' = 'manual'): void {
    this.held = false; this.side = null; this.requiresRelease = false;
    if (this.anchor) this.release(reason);
    if (this.mode === 'armed') this.mode = 'detached';
  }
  cancelHold(): void { this.holdEnd('cancel'); }
  pauseHold(): void { this.held = false; this.side = null; this.requiresRelease = false; }
  private release(reason: 'manual' | 'auto' | 'cancel'): void {
    if (this.mode === 'recovering') this.v = { x: 0, y: 16, z: 14 };
    this.anchor = null; this.mode = 'ballistic'; this.lastRelease = reason;
    this.requiresRelease = this.held;
  }
  private tangent(): void {
    if (!this.anchor) return;
    const nx = (this.p.x - this.anchor.x) / this.radius;
    const ny = (this.p.y - this.anchor.y) / this.radius;
    const nz = (this.p.z - this.anchor.z) / this.radius;
    const radial = this.v.x * nx + this.v.y * ny + this.v.z * nz;
    this.v.x -= radial * nx; this.v.y -= radial * ny; this.v.z -= radial * nz;
  }
  update(dt: number): void {
    if (!Number.isFinite(dt) || dt <= 0) return;
    const count = Math.ceil(dt * 240);
    for (let i = 0; i < count; i++) {
      if (this.mode === 'ready' || this.mode === 'recovery' || this.mode === 'complete') return;
      this.step(dt / count);
    }
  }
  private step(dt: number): void {
    this.elapsed += dt;
    if (this.mode === 'armed' && this.side && this.held && this.target(this.side)) {
      this.held = false; this.holdStart(this.side);
    }
    if (this.mode === 'recovering' && this.anchor) {
      const lift = Math.min(18 * dt, Math.max(0, this.radius - 8));
      this.p.y += lift; this.radius -= lift;
      if (this.radius <= 8.001) { this.mode = 'swinging'; this.v = { x: 0, y: 0, z: 18 }; }
      return;
    }
    this.protection = Math.max(0, this.protection - dt);
    const from = { ...this.p };
    this.v.y -= 16 * dt;
    this.v.z += Math.max(0, 18 - this.v.z) * 2 * dt;
    // Gentle corridor assist prevents sideways momentum accumulating forever.
    this.v.x += (-this.p.x * 3 - this.v.x * 2) * dt;
    if (this.anchor) this.tangent();
    const speed = Math.hypot(this.v.x, this.v.y, this.v.z);
    if (speed > 30) { const scale = 30 / speed; this.v.x *= scale; this.v.y *= scale; this.v.z *= scale; }
    this.p.x += this.v.x * dt; this.p.y += this.v.y * dt; this.p.z += this.v.z * dt;
    if (this.anchor) {
      const a = this.anchor;
      const factor = this.radius / Math.hypot(this.p.x - a.x, this.p.y - a.y, this.p.z - a.z);
      this.p.x = a.x + (this.p.x - a.x) * factor;
      this.p.y = a.y + (this.p.y - a.y) * factor;
      this.p.z = a.z + (this.p.z - a.z) * factor;
      this.tangent();
      if (this.p.z - a.z > this.radius * 0.8 || this.p.y > 22) this.release('auto');
    }
    if (this.p.y < this.config.floor || Math.abs(this.p.x) > this.config.wall) {
      const floorT = this.p.y < this.config.floor ? (from.y - this.config.floor) / (from.y - this.p.y) : 1;
      const wallT = Math.abs(this.p.x) > this.config.wall ?
        (Math.sign(this.p.x) * this.config.wall - from.x) / (this.p.x - from.x) : 1;
      const t = Math.max(0, Math.min(floorT, wallT));
      this.p = { x: from.x + (this.p.x - from.x) * t, y: from.y + (this.p.y - from.y) * t, z: from.z + (this.p.z - from.z) * t };
      this.freeze(); return;
    }
    for (const e of this.config.entities) {
      if (this.entityStates.has(e.id)) continue;
      if (hits3(from, this.p, e)) {
        this.entityStates.set(e.id, e.kind === 'gift' ? 'collected' : 'hit');
        if (e.kind === 'gift' && e.scored) this.emit({ t: 'gift', level: 2 });
        if (e.kind === 'hazard' && this.protection <= 0) { this.freeze(); return; }
      } else if (this.p.z > e.z + e.halfZ + 0.4) this.entityStates.set(e.id, 'missed');
    }
    if (this.p.z >= this.config.routeLength) {
      this.p.z = this.config.routeLength; this.mode = 'complete'; this.anchor = null; this.held = false;
      this.emit({ t: 'routeComplete', level: 2 });
    }
  }
  private freeze(): void {
    this.v = { x: 0, y: 0, z: 0 }; this.anchor = null;
    this.mode = 'recovery'; this.requiresRelease = this.held; this.recoveries++;
    this.emit({ t: 'incident', level: 2 });
  }
}
