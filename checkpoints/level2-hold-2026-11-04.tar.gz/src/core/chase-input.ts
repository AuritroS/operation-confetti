import type { Side } from '../levels/chase';
type Gesture = { type: 'holdStart'; side: Side } | { type: 'holdEnd' | 'holdCancel' | 'pauseToggle' | 'restart' };

/** Level 2 only: one active finger/key, side latched at press, release anywhere. */
export class ChaseInput {
  private active: string | null = null;
  private handler: (g: Gesture) => void = () => {};
  constructor(private readonly surface: HTMLElement) {}
  onGesture(handler: (g: Gesture) => void): void { this.handler = handler; }
  clearHeld(): void {
    const old = this.active; this.active = null;
    if (old?.startsWith('pointer:')) {
      const id = Number(old.slice(8));
      if (this.surface.hasPointerCapture(id)) this.surface.releasePointerCapture(id);
    }
  }
  attach(): void {
    this.surface.addEventListener('pointerdown', this.down);
    window.addEventListener('pointerup', this.up);
    window.addEventListener('pointercancel', this.cancel);
    this.surface.addEventListener('lostpointercapture', this.cancel);
    window.addEventListener('keydown', this.keyDown);
    window.addEventListener('keyup', this.keyUp);
    this.surface.addEventListener('contextmenu', this.menu);
  }
  detach(): void {
    this.clearHeld();
    this.surface.removeEventListener('pointerdown', this.down);
    window.removeEventListener('pointerup', this.up);
    window.removeEventListener('pointercancel', this.cancel);
    this.surface.removeEventListener('lostpointercapture', this.cancel);
    window.removeEventListener('keydown', this.keyDown);
    window.removeEventListener('keyup', this.keyUp);
    this.surface.removeEventListener('contextmenu', this.menu);
  }
  private menu = (e: Event) => e.preventDefault();
  private down = (e: PointerEvent) => {
    if (this.active || e.button !== 0) return;
    e.preventDefault();
    this.active = `pointer:${e.pointerId}`;
    const rect = this.surface.getBoundingClientRect();
    try { this.surface.setPointerCapture(e.pointerId); } catch { /* window up is the fallback */ }
    this.handler({ type: 'holdStart', side: e.clientX < rect.left + rect.width / 2 ? 'left' : 'right' });
  };
  private up = (e: PointerEvent) => {
    if (this.active !== `pointer:${e.pointerId}`) return;
    this.clearHeld(); this.handler({ type: 'holdEnd' });
  };
  private cancel = (e: PointerEvent) => {
    if (this.active !== `pointer:${e.pointerId}`) return;
    this.clearHeld(); this.handler({ type: 'holdCancel' });
  };
  private keyDown = (e: KeyboardEvent) => {
    if (e.target instanceof HTMLElement && e.target.matches('input,textarea,select,[contenteditable]')) return;
    if (['KeyP', 'Escape', 'KeyR'].includes(e.code)) {
      e.preventDefault();
      if (!e.repeat) this.handler({ type: e.code === 'KeyR' ? 'restart' : 'pauseToggle' });
      return;
    }
    const side = ['KeyA', 'ArrowLeft'].includes(e.code) ? 'left' : ['KeyD', 'ArrowRight'].includes(e.code) ? 'right' : null;
    if (!side) return;
    e.preventDefault();
    if (e.repeat || this.active) return;
    this.active = e.code; this.handler({ type: 'holdStart', side });
  };
  private keyUp = (e: KeyboardEvent) => {
    if (this.active !== e.code) return;
    e.preventDefault(); this.clearHeld(); this.handler({ type: 'holdEnd' });
  };
}
