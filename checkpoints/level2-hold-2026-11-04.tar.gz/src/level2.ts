import './level2.css';
import { ChaseInput } from './core/chase-input';
import { isTouchDevice, Lifecycle } from './core/lifecycle';
import { FixedLoop } from './core/loop';
import { POINTS, scoreRun } from './core/scoring';
import { CHASE, ChaseRunner } from './levels/chase';
import { ChaseScene } from './render/chase-scene';
import { DebugPanel, Hud } from './ui/hud';

document.body.dataset['level'] = '2';
document.title = 'Skyline Chase · Operation Confetti';
const app = document.getElementById('app')!;
const surface = document.getElementById('surface')!;
const rotate = document.getElementById('rotate')!;
const pausePill = document.getElementById('pause')!;
const pauseNote = document.getElementById('pause-note')!;
const pauseButton = document.getElementById('btn-pause') as HTMLButtonElement;
const replay = document.createElement('button');
replay.id = 'btn-replay';
replay.type = 'button';
replay.className = 'hud__btn';
replay.textContent = 'Replay';
replay.setAttribute('aria-label', 'Restart level 2');
pauseButton.before(replay);
const heading = document.createElement('div');
heading.className = 'swing-heading';
heading.innerHTML = '<small>Level 02 · 3D swing trial</small><strong>Skyline Chase</strong>';
app.append(heading);
const instruction = document.createElement('div');
instruction.className = 'swing-instruction';
instruction.innerHTML = '<strong id="swing-action">Hold to grapple</strong><small id="swing-note">Release to fly. Catch the next anchor.</small>';
app.append(instruction);
const action = document.getElementById('swing-action')!;
const note = document.getElementById('swing-note')!;
const sides = document.createElement('div');
sides.className = 'swing-sides';
sides.innerHTML = '<span data-side="left">← HOLD LEFT</span><span data-side="right">HOLD RIGHT →</span>';
app.append(sides);
const reward = document.createElement('span');
reward.className = 'swing-reward';
reward.hidden = true;
app.append(reward);
const collected = new Set<string>();
const hint = document.getElementById('hint')!;
hint.innerHTML = '<span><kbd>A</kbd> / <kbd>D</kbd> hold left / right</span><span><kbd>P</kbd> pause · <kbd>R</kbd> replay · <kbd>I</kbd> debug</span>';
hint.hidden = isTouchDevice();

const params = new URLSearchParams(location.search);
const hud = new Hud();
const debug = new DebugPanel();
let debugVisible = params.has('debug') && !params.has('clean');
debug.setVisible(debugVisible);
const view = new ChaseScene(document.getElementById('stage') as HTMLCanvasElement, CHASE);
const input = new ChaseInput(surface);
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let runner: ChaseRunner;
let paused = false;

function makeRunner(): ChaseRunner {
  const next = new ChaseRunner(CHASE);
  next.onEvent((event) => {
    hud.setScore(scoreRun(next.events).total);
    if (event.t === 'incident') hud.showPenalty(POINTS.incident);
  });
  return next;
}
runner = makeRunner();
hud.reset();

function banner(title: string, message: string): void {
  pausePill.firstChild!.textContent = `${title} `;
  pauseNote.textContent = message;
  pausePill.hidden = false;
}

function update(dt: number): void {
  runner.update(dt);
  const snap = runner.snapshot;
  for (const entity of CHASE.entities) {
    if (runner.entityStates.get(entity.id) !== 'collected' || collected.has(entity.id)) continue;
    collected.add(entity.id);
    reward.textContent = entity.scored ? '+100' : 'Practice gift';
    reward.hidden = true;
    void reward.offsetWidth;
    reward.hidden = false;
  }
  view.update(snap, dt, reducedMotion, runner.entityStates);
  for (const side of ['left', 'right'] as const) {
    const chip = sides.querySelector<HTMLElement>(`[data-side="${side}"]`)!;
    chip.classList.toggle('active', snap.held && snap.side === side);
    chip.classList.toggle('available', !!snap.targets[side]);
  }
  if (snap.complete) {
    action.textContent = 'Course complete';
    note.textContent = 'Tap Replay for another run.';
  } else if (snap.mode === 'recovery') {
    action.textContent = 'Hold to reattach';
    note.textContent = snap.requiresRelease ? 'Lift, then hold either side. The route is frozen.' : 'Hold either side to pull up and continue.';
  } else if (snap.mode === 'recovering') {
    action.textContent = 'Hold — pulling you up';
    note.textContent = 'Your swing resumes from here.';
  } else if (snap.requiresRelease) {
    action.textContent = 'Release, then hold again';
    note.textContent = 'One press for each swing.';
  } else if (snap.mode === 'swinging') {
    action.textContent = 'Release to fly';
    note.textContent = `${snap.anchor?.side === 'left' ? 'Left' : 'Right'} anchor · ${snap.radius.toFixed(0)} m rope · then catch either side`;
  } else if (snap.mode === 'armed') {
    action.textContent = 'Hold — finding an anchor';
    note.textContent = `Waiting for a reachable ${snap.side} anchor.`;
  } else {
    action.textContent = snap.mode === 'ready' ? 'Hold left or right to start' : 'Catch your next anchor';
    note.textContent = snap.mode === 'ready' ? 'Hold to swing. Release to fly. Gold gifts · pink obstacles.' :
      'Attach sooner for a longer rope. Later for a tighter arc.';
  }
}

function render(): void {
  view.render();
  const s = runner.snapshot;
  debug.set({
    level: '2 · 3D control trial', state: s.mode, held: s.held ? 'yes' : 'no',
    rearm: s.requiresRelease ? 'release required' : 'ready',
    distance: `${s.z.toFixed(1)} / ${CHASE.routeLength}`,
    height: s.y.toFixed(2), velocity: `${s.vz.toFixed(1)} / ${s.vy.toFixed(1)}`,
    anchor: s.anchor?.id ?? 'none', rope: s.radius.toFixed(2),
    side: s.side ?? 'none', lateral: s.x.toFixed(2),
    swings: s.swings, recoveries: s.recoveries,
    gifts: `${runner.events.filter((e) => e.t === 'gift').length}/4`,
    release: s.lastRelease ?? 'none', fps: loop.stats.fps,
    draws: view.stage.drawCalls, tris: view.stage.triangles,
  });
}
const loop = new FixedLoop({ update, render });
const lifecycle = new Lifecycle({
  onPause: () => {
    paused = true;
    runner.pauseHold();
    input.clearHeld();
    loop.stop();
    pauseButton.textContent = '▶';
    pauseButton.setAttribute('aria-label', 'Resume');
    banner('Paused', 'Hold the screen or press P to resume');
  },
  onResumeRequested: () => {}, // Returning to the tab never resumes by itself.
  onOrientation: (landscape) => { rotate.hidden = !landscape; },
});

function resume(): void {
  if (!rotate.hidden) return;
  for (const reason of lifecycle.pauseReasons) lifecycle.clear(reason);
  paused = false;
  pauseButton.textContent = 'II';
  pauseButton.setAttribute('aria-label', 'Pause');
  pausePill.hidden = true;
  loop.start();
}

function restart(): void {
  runner.pauseHold();
  input.clearHeld();
  runner = makeRunner();
  view.reset();
  hud.reset();
  collected.clear();
  reward.hidden = true;
  update(0);
  render();
  // Restart while rotated/hidden is still paused; no background simulation.
  if (document.visibilityState === 'visible' && rotate.hidden) resume();
}

input.onGesture((g) => {
  if (g.type === 'restart') { restart(); return; }
  if (g.type === 'pauseToggle') { if (paused) resume(); else lifecycle.pause('user'); return; }
  if (g.type === 'holdStart') {
    if (paused) resume();
    if (!paused) runner.holdStart(g.side);
  } else if (!paused && g.type === 'holdEnd') runner.holdEnd();
  else if (!paused && g.type === 'holdCancel') runner.cancelHold();
});
const onDebugKey = (e: KeyboardEvent) => {
  if (e.code !== 'KeyI' || e.repeat || (e.target instanceof HTMLElement && e.target.matches('input,textarea,[contenteditable]'))) return;
  debugVisible = !debugVisible;
  debug.setVisible(debugVisible);
};
window.addEventListener('keydown', onDebugKey);
const togglePause = () => { pauseButton.blur(); if (paused) resume(); else lifecycle.pause('user'); };
const replayRun = () => { replay.blur(); restart(); };
pauseButton.addEventListener('click', togglePause);
replay.addEventListener('click', replayRun);
input.attach();
lifecycle.attach();
update(0);
render();
if (!paused) loop.start();

// Passive state/projection inspection for browser checks, never bundled into
// the production game. Tests exercise real inputs rather than mutating state.
if (import.meta.env.DEV) {
  Object.assign(window, { __swingReview: {
    get snapshot() { return runner.snapshot; },
    get paused() { return paused; },
    framing: () => view.framing(),
  } });
}

if (import.meta.hot) import.meta.hot.dispose(() => {
  loop.stop(); input.detach(); lifecycle.detach(); view.dispose();
  window.removeEventListener('keydown', onDebugKey);
  pauseButton.removeEventListener('click', togglePause);
  replay.removeEventListener('click', replayRun);
  replay.remove(); heading.remove(); instruction.remove(); reward.remove(); sides.remove();
});
