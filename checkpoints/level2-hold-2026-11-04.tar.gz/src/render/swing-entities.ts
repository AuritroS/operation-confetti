import { BoxGeometry, Group, InstancedMesh, MeshBasicMaterial, Object3D } from 'three';
import type { SwingConfig, SwingSnapshot } from '../levels/swing-types';

type EntityStates = ReadonlyMap<string, 'collected' | 'hit' | 'missed'>;

/** Collider-sized primitive gifts/hazards. Static content, pooled draw calls. */
export class SwingEntities {
  readonly group = new Group();
  private readonly geometry = new BoxGeometry(1, 1, 1);
  private readonly gold = new MeshBasicMaterial({ color: 0xffc568, fog: false });
  private readonly ribbonMaterial = new MeshBasicMaterial({ color: 0xfff1c9, fog: false });
  private readonly danger = new MeshBasicMaterial({ color: 0xf04cda, fog: false });
  private readonly fillMaterial = new MeshBasicMaterial({ color: 0xcc29c3, fog: false, transparent: true, opacity: 0.13, depthWrite: false });
  private readonly gifts: InstancedMesh;
  private readonly ribbons: InstancedMesh;
  private readonly frames: InstancedMesh;
  private readonly fills: InstancedMesh;
  private readonly dummy = new Object3D();
  private readonly pickupTimes = new Map<string, number>();

  constructor(private readonly config: SwingConfig) {
    const n = Math.max(1, config.entities.length);
    this.gifts = new InstancedMesh(this.geometry, this.gold, n);
    this.ribbons = new InstancedMesh(this.geometry, this.ribbonMaterial, n * 2);
    this.frames = new InstancedMesh(this.geometry, this.danger, n * 4);
    this.fills = new InstancedMesh(this.geometry, this.fillMaterial, n);
    for (const mesh of [this.gifts, this.ribbons, this.frames, this.fills]) {
      mesh.frustumCulled = false;
      mesh.count = 0;
      this.group.add(mesh);
    }
  }

  update(s: SwingSnapshot, states: EntityStates): void {
    let gifts = 0; let ribbons = 0; let frames = 0; let fills = 0;
    for (const e of this.config.entities) {
      const relative = e.z - s.z;
      const state = states.get(e.id);
      if (relative < -20 || relative > 100 || state === 'missed' || state === 'hit') continue;
      if (e.kind === 'gift') {
        let scale = 1;
        let rise = 0;
        if (state === 'collected') {
          if (!this.pickupTimes.has(e.id)) this.pickupTimes.set(e.id, s.elapsed);
          const t = (s.elapsed - this.pickupTimes.get(e.id)!) / 0.35;
          if (t >= 1) continue;
          scale = (1 - t) * (1 + t);
          rise = t * 1.5;
        }
        this.place(this.gifts, gifts++, e.y + rise, -relative,
          e.halfY * 2 * scale, e.halfZ * 2 * scale, 1.1 * scale);
        this.place(this.ribbons, ribbons++, e.y + rise, -relative,
          e.halfY * 2.04 * scale, 0.15 * scale, 1.14 * scale);
        this.place(this.ribbons, ribbons++, e.y + rise, -relative,
          0.15 * scale, e.halfZ * 2.04 * scale, 1.14 * scale);
      } else {
        // Bars bound the exact (z,y) collision box. The tinted interior
        // makes its whole occupied height readable, with space above/below.
        this.place(this.fills, fills++, e.y, -relative, e.halfY * 2, e.halfZ * 2, 1.1);
        for (const sign of [-1, 1]) {
          this.place(this.frames, frames++, e.y + sign * e.halfY, -relative, 0.18, e.halfZ * 2, 1.15);
          this.place(this.frames, frames++, e.y, -relative + sign * e.halfZ, e.halfY * 2, 0.18, 1.15);
        }
      }
    }
    for (const [mesh, count] of [[this.gifts, gifts], [this.ribbons, ribbons], [this.frames, frames], [this.fills, fills]] as const) {
      mesh.count = count;
      mesh.instanceMatrix.needsUpdate = true;
    }
  }

  private place(mesh: InstancedMesh, i: number, y: number, z: number, height: number, depth: number, width: number): void {
    this.dummy.position.set(0, y, z);
    this.dummy.scale.set(width, height, depth);
    this.dummy.updateMatrix();
    mesh.setMatrixAt(i, this.dummy.matrix);
  }

  reset(): void { this.pickupTimes.clear(); }
  dispose(): void {
    this.group.removeFromParent();
    this.geometry.dispose(); this.gold.dispose(); this.ribbonMaterial.dispose();
    this.danger.dispose(); this.fillMaterial.dispose();
    this.gifts.dispose(); this.ribbons.dispose(); this.frames.dispose(); this.fills.dispose();
  }
}
