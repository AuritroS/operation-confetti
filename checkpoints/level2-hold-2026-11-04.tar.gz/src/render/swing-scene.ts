/** Primitive presentation for the independent level 2 feel review. */
import {
  BoxGeometry, BufferGeometry, CapsuleGeometry, Color, Float32BufferAttribute,
  FogExp2, Group, InstancedMesh, Line, LineBasicMaterial, Mesh,
  MeshStandardMaterial, Object3D, Vector3,
} from 'three';
import type { SwingConfig, SwingSnapshot } from '../levels/swing-types';
import { Stage } from './stage';
import { SwingEntities } from './swing-entities';

export class SwingScene {
  readonly stage: Stage;
  private readonly root = new Group();
  private readonly player = new Group();
  private readonly cable: Line;
  private readonly cablePoints = new Float32Array(6);
  private readonly anchors: Mesh[] = [];
  private readonly supports: InstancedMesh;
  private readonly blocks: InstancedMesh;
  private readonly entities: SwingEntities;
  private readonly dummy = new Object3D();
  private readonly point = new Vector3();
  private readonly idleMaterial = new MeshStandardMaterial({ color: 0x68829e, emissive: 0x17263c, roughness: 0.8 });
  private readonly readyMaterial = new MeshStandardMaterial({ color: 0x90f3ff, emissive: 0x3b879c, emissiveIntensity: 1.5, roughness: 0.6, fog: false });
  private readonly attachedMaterial = new MeshStandardMaterial({ color: 0xffd083, emissive: 0xb77733, emissiveIntensity: 1.5, roughness: 0.6, fog: false });
  private readonly bodyMaterial = new MeshStandardMaterial({ color: 0x457be0, emissive: 0x102a50, roughness: 0.85, fog: false });
  private readonly box = new BoxGeometry(1, 1, 1);
  private readonly capsule = new CapsuleGeometry(0.32, 0.7, 4, 8);
  private pullback = 0;
  private focusZ = -6;
  private focusY = 3;
  private latest: SwingSnapshot | null = null;

  constructor(canvas: HTMLCanvasElement, private readonly config: SwingConfig) {
    this.stage = new Stage(canvas);
    this.stage.scene.background = new Color(0x101a2b);
    this.stage.scene.fog = new FogExp2(0x101a2b, 0.022);
    this.stage.scene.add(this.root);
    this.stage.observe();
    this.entities = new SwingEntities(config);
    this.root.add(this.entities.group);

    const body = new Mesh(this.capsule, this.bodyMaterial);
    this.player.add(body);
    const visor = new Mesh(this.box, this.attachedMaterial);
    visor.scale.set(0.55, 0.17, 0.45);
    visor.position.set(0.16, 0.36, 0);
    this.player.add(visor);
    this.root.add(this.player);

    const cableGeometry = new BufferGeometry();
    cableGeometry.setAttribute('position', new Float32BufferAttribute(this.cablePoints, 3));
    this.cable = new Line(cableGeometry, new LineBasicMaterial({ color: 0xffd083 }));
    this.cable.frustumCulled = false;
    this.root.add(this.cable);

    // Pool the visible anchors. Geometry is diagnostic, never a collider.
    for (let i = 0; i < 12; i++) {
      const mesh = new Mesh(this.box, this.idleMaterial);
      mesh.scale.setScalar(0.55);
      this.anchors.push(mesh);
      this.root.add(mesh);
    }
    this.supports = new InstancedMesh(this.box,
      new MeshStandardMaterial({ color: 0x354762, roughness: 1 }), 36);
    this.supports.frustumCulled = false;
    this.root.add(this.supports);
    this.blocks = new InstancedMesh(this.box,
      new MeshStandardMaterial({ color: 0x25344b, roughness: 1 }), 40);
    this.blocks.frustumCulled = false;
    this.root.add(this.blocks);
  }

  update(snap: SwingSnapshot, dt: number, reducedMotion: boolean,
    states: ReadonlyMap<string, 'collected' | 'hit' | 'missed'>): void {
    this.latest = snap;
    this.entities.update(snap, states);
    this.player.position.set(0, snap.y, 0);
    this.player.rotation.x = snap.anchor ? -snap.angle * 0.7 : -Math.atan2(snap.vy, Math.max(1, snap.vz)) * 0.55;
    this.bodyMaterial.emissive.setHex(snap.invulnerable ? 0x204854 : 0x102a50);

    this.cable.visible = snap.anchor !== null;
    if (snap.anchor) {
      const p = this.cable.geometry.getAttribute('position');
      p.setXYZ(0, 0, snap.y + 0.5, 0);
      p.setXYZ(1, 0, snap.anchor.y, -(snap.anchor.z - snap.z));
      p.needsUpdate = true;
    }

    const special = snap.eligible?.id.startsWith('recovery-') ? snap.eligible :
      snap.anchor?.id.startsWith('recovery-') ? snap.anchor : null;
    const visible = [
      ...(special ? [special] : []),
      ...this.config.anchors.filter((a) => a.z > snap.z - 30 && a.z < snap.z + 110 &&
        (!special || Math.abs(a.z - special.z) > 2)),
    ];
    let supportCount = 0;
    this.anchors.forEach((mesh, i) => {
      const a = visible[i];
      mesh.visible = !!a;
      if (!a) return;
      mesh.position.set(0, a.y, -(a.z - snap.z));
      mesh.material = a.id === snap.anchor?.id ? this.attachedMaterial :
        a.id === snap.eligible?.id ? this.readyMaterial : this.idleMaterial;
      mesh.scale.setScalar(a.id === snap.eligible?.id ? 0.85 : 0.55);
      // An overhead arm and a pole placed outside the swing plane.
      this.instance(this.supports, supportCount++, -2.5, a.y, -(a.z - snap.z), 5, 0.13, 0.13);
      if (!a.id.startsWith('recovery-')) {
        this.instance(this.supports, supportCount++, -5, (a.y + this.config.floor - 6) / 2,
          -(a.z - snap.z), 0.2, a.y - this.config.floor + 6, 0.2);
      }
    });
    this.supports.count = supportCount;
    this.supports.instanceMatrix.needsUpdate = true;

    // Plain blocks below the swing plane give movement a reference without
    // importing level 1's environment or committing to final city art.
    const base = Math.floor(snap.z / 12) * 12;
    let blockCount = 0;
    for (let i = -3; i < 14; i++) {
      const z = base + i * 12;
      const h = 3 + ((Math.floor(z / 12) % 3 + 3) % 3);
      this.instance(this.blocks, blockCount++, -10, this.config.floor - 6 - h / 2, -(z - snap.z), 5, h, 8);
      this.instance(this.blocks, blockCount++, 10, this.config.floor - 8, -(z - snap.z), 3, 2, 8);
    }
    // Distant roofs supply a low reference. The long starter runway is gone.
    this.instance(this.blocks, blockCount++, 0, this.config.floor - 8, -(this.config.routeLength - 5 - snap.z), 5.5, 2.5, 26);
    this.blocks.count = blockCount;
    this.blocks.instanceMatrix.needsUpdate = true;

    const goal = reducedMotion ? 0 : Math.max(0, snap.vz - 13) * 0.2;
    this.pullback += (goal - this.pullback) * (1 - Math.exp(-dt * 3));
    // Oblique side-trailing. Stable vertical framing lets the player read
    // height and judge the next release; only speed gently changes distance.
    const aspect = this.stage.camera.aspect;
    const extra = Math.max(0, 0.48 / aspect - 1) * 9;
    // Keep both ends of a live cable framed, including the rising half when
    // its anchor passes behind Matthew. Detached, gently look ahead again.
    const targetAnchor = snap.anchor ?? snap.eligible;
    const focus = targetAnchor ? -(targetAnchor.z - snap.z) * 0.5 : -6;
    this.focusZ += (focus - this.focusZ) * (1 - Math.exp(-dt * 12));
    const targetY = targetAnchor ? (snap.y + targetAnchor.y) / 2 : snap.y + 3;
    this.focusY += (targetY - this.focusY) * (1 - Math.exp(-dt * 5));
    this.stage.camera.position.set(22 + extra + this.pullback, this.focusY + 5, this.focusZ + 32 + extra);
    this.stage.camera.lookAt(0, this.focusY, this.focusZ);
  }

  private instance(mesh: InstancedMesh, i: number, x: number, y: number, z: number, sx: number, sy: number, sz: number): void {
    this.dummy.position.set(x, y, z);
    this.dummy.scale.set(sx, sy, sz);
    this.dummy.updateMatrix();
    mesh.setMatrixAt(i, this.dummy.matrix);
  }

  render(): void { this.stage.render(); }

  reset(): void { this.pullback = 0; this.focusZ = -6; this.focusY = 3; this.entities.reset(); }

  /** Passive review probe: measures the actual camera projection. */
  framing(): { player: number[]; anchor: number[] | null; entities: { id: string; point: number[] }[] } {
    const snap = this.latest;
    const project = (y: number, z: number) => {
      this.point.set(0, y, z).project(this.stage.camera);
      return [this.point.x, this.point.y, this.point.z];
    };
    return {
      player: project(snap?.y ?? 5, 0),
      anchor: snap?.eligible ? project(snap.eligible.y, -(snap.eligible.z - snap.z)) :
        snap?.anchor ? project(snap.anchor.y, -(snap.anchor.z - snap.z)) : null,
      entities: this.config.entities.filter((e) => e.z >= (snap?.z ?? 0) && e.z < (snap?.z ?? 0) + 45)
        .map((e) => ({ id: e.id, point: project(e.y, -(e.z - (snap?.z ?? 0))) })),
    };
  }

  dispose(): void {
    this.root.removeFromParent();
    this.entities.dispose();
    this.box.dispose(); this.capsule.dispose();
    this.cable.geometry.dispose(); (this.cable.material as LineBasicMaterial).dispose();
    this.idleMaterial.dispose(); this.readyMaterial.dispose();
    this.attachedMaterial.dispose(); this.bodyMaterial.dispose();
    (this.supports.material as MeshStandardMaterial).dispose();
    (this.blocks.material as MeshStandardMaterial).dispose();
    this.supports.dispose(); this.blocks.dispose();
    this.stage.dispose();
  }
}
