import {
  BoxGeometry, BufferGeometry, Color, Float32BufferAttribute, FogExp2, Group,
  InstancedMesh, Line, LineBasicMaterial, Mesh, MeshBasicMaterial, MeshStandardMaterial,
  Object3D, OctahedronGeometry, Vector3,
} from 'three';
import { Stage } from './stage';
import type { ChaseConfig, ChaseSnapshot, Point3 } from '../levels/chase';

/** Small pooled city, actual 3D landmarks, and a stable trailing camera. */
export class ChaseScene {
  readonly stage: Stage;
  private root = new Group();
  private player = new Group();
  private box = new BoxGeometry();
  private jewel = new OctahedronGeometry(0.7);
  private cityMaterial = new MeshStandardMaterial({ color: 0x24364e, roughness: 1 });
  private trimMaterial = new MeshBasicMaterial({ color: 0x567d99 });
  private gold = new MeshBasicMaterial({ color: 0xffcb72, fog: false });
  private white = new MeshBasicMaterial({ color: 0xfff2d0, fog: false });
  private danger = new MeshBasicMaterial({ color: 0xe64f91 });
  private darkDanger = new MeshStandardMaterial({ color: 0x542744, roughness: 1 });
  private blue = new MeshStandardMaterial({ color: 0x438bfa, emissive: 0x102b62, roughness: 0.7, fog: false });
  private ready = new MeshBasicMaterial({ color: 0x8df7ff, fog: false });
  private idle = new MeshBasicMaterial({ color: 0x587d98 });
  private buildings: InstancedMesh;
  private windows: InstancedMesh;
  private anchors: Mesh[] = [];
  private contents = new Map<string, Group>();
  private cable: Line;
  private dummy = new Object3D();
  private probe = new Vector3();
  private latest: ChaseSnapshot | null = null;
  private followY = 6;
  private followX = 0;
  private distance = 30;

  constructor(canvas: HTMLCanvasElement, private config: ChaseConfig) {
    this.stage = new Stage(canvas);
    this.stage.scene.background = new Color(0x101d32);
    this.stage.scene.fog = new FogExp2(0x101d32, 0.012);
    this.stage.scene.add(this.root);
    this.stage.observe();
    this.buildings = new InstancedMesh(this.box, this.cityMaterial, 100);
    this.windows = new InstancedMesh(this.box, this.trimMaterial, 600);
    this.buildings.frustumCulled = this.windows.frustumCulled = false;
    this.root.add(this.buildings, this.windows);

    const body = this.cube(this.player, this.blue, 0, 0, 0, 0.8, 1, 0.45);
    body.rotation.x = -0.15;
    this.cube(this.player, this.blue, 0, 0.85, 0, 0.52, 0.55, 0.5);
    this.cube(this.player, this.gold, 0, 0.88, -0.26, 0.44, 0.13, 0.04);
    for (const side of [-1, 1]) {
      const arm = this.cube(this.player, this.blue, side * 0.56, 0.28, 0, 0.24, 0.85, 0.27);
      arm.rotation.z = side * -0.5;
      const leg = this.cube(this.player, this.blue, side * 0.23, -0.8, 0.12, 0.27, 0.8, 0.3);
      leg.rotation.x = 0.35;
    }
    this.cube(this.player, this.gold, 0, -0.25, 0.24, 0.65, 0.15, 0.04);
    this.root.add(this.player);
    const geometry = new BufferGeometry();
    geometry.setAttribute('position', new Float32BufferAttribute(new Float32Array(6), 3));
    this.cable = new Line(geometry, new LineBasicMaterial({ color: 0xffefbc, fog: false }));
    this.cable.frustumCulled = false;
    this.root.add(this.cable);
    for (let i = 0; i < 18; i++) {
      const a = new Mesh(this.jewel, this.idle);
      this.anchors.push(a); this.root.add(a);
    }
    for (const e of config.entities) {
      const group = new Group();
      if (e.kind === 'gift') {
        this.cube(group, this.gold, 0, 0, 0, 1.5, 1.5, 1.5);
        this.cube(group, this.white, 0, 0, 0, 0.22, 1.54, 1.54);
        this.cube(group, this.white, 0, 0, 0, 1.54, 0.22, 1.54);
      } else {
        this.cube(group, this.darkDanger, 0, 0, 0, e.halfX * 2, e.halfY * 2, e.halfZ * 2);
        for (const y of [-e.halfY, e.halfY]) {
          this.cube(group, this.danger, 0, y, e.halfZ + 0.02, e.halfX * 2, 0.15, 0.12);
        }
        for (const x of [-e.halfX, e.halfX]) {
          this.cube(group, this.danger, x, 0, e.halfZ + 0.02, 0.15, e.halfY * 2, 0.12);
        }
      }
      this.contents.set(e.id, group); this.root.add(group);
    }
  }
  private cube(parent: Group, material: MeshBasicMaterial | MeshStandardMaterial,
    x: number, y: number, z: number, sx: number, sy: number, sz: number): Mesh {
    const mesh = new Mesh(this.box, material);
    mesh.position.set(x, y, z); mesh.scale.set(sx, sy, sz); parent.add(mesh); return mesh;
  }
  private instance(mesh: InstancedMesh, i: number, x: number, y: number, z: number, sx: number, sy: number, sz: number): void {
    this.dummy.position.set(x, y, z); this.dummy.scale.set(sx, sy, sz); this.dummy.updateMatrix();
    mesh.setMatrixAt(i, this.dummy.matrix);
  }
  update(s: ChaseSnapshot, dt: number, reducedMotion: boolean,
    states: ReadonlyMap<string, 'collected' | 'hit' | 'missed'>): void {
    this.latest = s;
    this.player.position.set(s.x, s.y, 0);
    this.player.rotation.set(-Math.atan2(s.vy, Math.max(8, s.vz)) * 0.45, 0, -s.vx * 0.035);
    this.cable.visible = !!s.anchor;
    if (s.anchor) {
      const p = this.cable.geometry.getAttribute('position');
      p.setXYZ(0, s.x, s.y + 0.6, 0);
      p.setXYZ(1, s.anchor.x, s.anchor.y, s.z - s.anchor.z); p.needsUpdate = true;
    }
    let blocks = 0, trims = 0;
    const base = Math.floor(s.z / 18) * 18;
    for (let i = -2; i < 11; i++) {
      const z = base + i * 18;
      for (const side of [-1, 1]) {
        const height = 44 + Math.sin(z * 0.24 + side) * 9;
        this.instance(this.buildings, blocks++, side * 18, -22 + height / 2, s.z - z, 8, height, 15);
        for (let floor = -12; floor < height - 23; floor += 5) {
          this.instance(this.windows, trims++, side * 13.96, floor, s.z - z, 0.08, 0.18, 11);
          this.instance(this.windows, trims++, side * 18, floor, s.z - z + 7.55, 6, 0.18, 0.08);
        }
      }
      this.instance(this.windows, trims++, 0, -20.9, s.z - z, 0.15, 0.05, 8);
    }
    this.instance(this.buildings, blocks++, 0, -22, -60, 28, 2, 260);
    // Finish arch is a visible destination even before the last attachment.
    this.instance(this.windows, trims++, 0, 14, s.z - this.config.routeLength, 24, 0.45, 0.45);
    for (const side of [-1, 1]) this.instance(this.windows, trims++, side * 11, -2, s.z - this.config.routeLength, 0.45, 32, 0.45);
    const rescue = s.mode === 'recovery' ? s.targets.left : s.anchor?.id === 'rescue' ? s.anchor : null;
    const visible = [...(rescue ? [rescue] : []), ...this.config.anchors.filter((a) => a.z > s.z - 12 && a.z < s.z + 145)];
    this.anchors.forEach((mesh, i) => {
      const a = visible[i]; mesh.visible = !!a; if (!a) return;
      const active = a.id === s.anchor?.id;
      const ready = a.id === s.targets.left?.id || a.id === s.targets.right?.id;
      mesh.position.set(a.x, a.y, s.z - a.z);
      mesh.material = active ? this.gold : ready ? this.ready : this.idle;
      mesh.scale.setScalar(active || ready ? 1.15 : 0.65);
      if (a.id !== 'rescue') {
        const wall = Math.sign(a.x) * 14;
        this.instance(this.buildings, blocks++, (wall + a.x) / 2, a.y, s.z - a.z, Math.abs(wall - a.x), 0.3, 0.3);
      }
    });
    this.buildings.count = blocks; this.windows.count = trims;
    this.buildings.instanceMatrix.needsUpdate = this.windows.instanceMatrix.needsUpdate = true;
    for (const e of this.config.entities) {
      const mesh = this.contents.get(e.id)!;
      mesh.visible = !states.has(e.id) && e.z > s.z - 4 && e.z < s.z + 140;
      mesh.position.set(e.x, e.y, s.z - e.z);
      if (e.kind === 'gift') mesh.rotation.y = reducedMotion ? 0 : s.elapsed * 0.65;
    }
    const blend = dt === 0 ? 1 : 1 - Math.exp(-dt * 5);
    const focusAnchor = s.anchor ?? (s.mode === 'recovery' ? s.targets.left : null);
    const targetY = focusAnchor ? s.y * 0.65 + focusAnchor.y * 0.35 : s.y;
    const targetX = focusAnchor ? s.x * 0.65 + focusAnchor.x * 0.35 : s.x * 0.7;
    this.followY += (targetY - this.followY) * blend;
    this.followX += (targetX - this.followX) * blend;
    const distance = 30 + Math.max(0, 0.48 / this.stage.camera.aspect - 1) * 14 +
      (focusAnchor ? Math.max(0, s.z - focusAnchor.z) * 0.8 : 0);
    this.distance += (distance - this.distance) * blend;
    this.stage.camera.position.set(this.followX, this.followY + 7, this.distance);
    this.stage.camera.lookAt(this.followX * 0.7, this.followY + 3, -24);
  }
  framing(): { player: number[]; anchors: number[][]; entities: { id: string; point: number[] }[]; draws: number; triangles: number } {
    const s = this.latest;
    const project = (p: Point3) => this.probe.set(p.x, p.y, (s?.z ?? 0) - p.z).project(this.stage.camera).toArray();
    return { player: project(s ?? this.config.start),
      anchors: s ? [s.anchor, s.targets.left, s.targets.right].filter((a) => !!a).map((a) => project(a)) : [],
      entities: this.config.entities.filter((e) => e.z >= (s?.z ?? 0) && e.z < (s?.z ?? 0) + 80)
        .map((e) => ({ id: e.id, point: project(e) })),
      draws: this.stage.drawCalls, triangles: this.stage.triangles };
  }
  render(): void { this.stage.render(); }
  reset(): void { this.followY = this.config.start.y; this.followX = 0; this.distance = 30; }
  dispose(): void {
    this.root.removeFromParent(); this.box.dispose(); this.jewel.dispose();
    this.cable.geometry.dispose(); (this.cable.material as LineBasicMaterial).dispose();
    for (const m of [this.cityMaterial, this.trimMaterial, this.gold, this.white, this.danger, this.darkDanger, this.blue, this.ready, this.idle]) m.dispose();
    this.buildings.dispose(); this.windows.dispose(); this.stage.dispose();
  }
}
