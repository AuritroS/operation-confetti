import { describe, expect, it } from 'vitest';
import { CHASE, ChaseRunner, hits3 } from '../src/levels/chase';
import type { ChaseConfig, Side } from '../src/levels/chase';

const advance = (r: ChaseRunner, seconds: number) => { for (let i = 0; i < Math.round(seconds * 60); i++) r.update(1 / 60); };
const empty = (): ChaseConfig => ({ ...CHASE, entities: [] });

describe('3D chase control trial', () => {
  it('waits for the first deliberate input', () => {
    const r = new ChaseRunner(); const initial = r.snapshot;
    advance(r, 10); expect(r.snapshot).toEqual(initial);
  });
  it('selects the requested side without snapping and mirrors the first arc', () => {
    const left = new ChaseRunner(empty()), right = new ChaseRunner(empty());
    left.holdStart('left'); right.holdStart('right');
    expect(left.snapshot.x).toBe(0); expect(left.snapshot.y).toBe(6); expect(left.snapshot.z).toBe(0);
    expect(left.snapshot.anchor?.side).toBe('left'); expect(right.snapshot.anchor?.side).toBe('right');
    advance(left, 0.8); advance(right, 0.8);
    expect(left.snapshot.x).toBeLessThan(-1);
    expect(right.snapshot.x).toBeCloseTo(-left.snapshot.x, 8);
    expect(right.snapshot.y).toBeCloseTo(left.snapshot.y, 8);
    expect(right.snapshot.z).toBeCloseTo(left.snapshot.z, 8);
  });
  it('keeps rope length fixed and releases tangent momentum unchanged', () => {
    const r = new ChaseRunner(empty()); r.holdStart('left');
    const radius = r.snapshot.radius;
    for (let i = 0; i < 60; i++) {
      r.update(1 / 60); const s = r.snapshot; const a = s.anchor!;
      expect(a).not.toBeNull();
      expect(Math.hypot(s.x - a.x, s.y - a.y, s.z - a.z)).toBeCloseTo(radius, 8);
      expect((s.x - a.x) * s.vx + (s.y - a.y) * s.vy + (s.z - a.z) * s.vz).toBeCloseTo(0, 8);
    }
    const s = r.snapshot; r.holdEnd();
    expect([r.snapshot.vx, r.snapshot.vy, r.snapshot.vz]).toEqual([s.vx, s.vy, s.vz]);
    expect(r.snapshot.mode).toBe('ballistic');
  });
  it('a later attachment to the same anchor produces a shorter rope', () => {
    const early = new ChaseRunner(empty()); early.holdStart('left');
    const late = new ChaseRunner({ ...empty(), start: { ...CHASE.start, z: 6 } }); late.holdStart('left');
    expect(late.snapshot.anchor?.id).toBe('left-0');
    expect(late.snapshot.radius).toBeLessThan(early.snapshot.radius);
  });
  it('held input auto releases once and requires a fresh press', () => {
    const r = new ChaseRunner(empty()); r.holdStart('left');
    advance(r, 3); expect(r.snapshot.lastRelease).toBe('auto');
    expect(r.snapshot.requiresRelease).toBe(true); expect(r.snapshot.swings).toBe(1);
    r.holdStart('right'); expect(r.snapshot.swings).toBe(1);
    r.holdEnd(); expect(r.snapshot.requiresRelease).toBe(false);
  });
  it('freezes failures and recovers continuously at the same route position', () => {
    const r = new ChaseRunner(empty()); r.holdStart('left'); r.holdEnd(); advance(r, 10);
    expect(r.snapshot.mode).toBe('recovery');
    const s = r.snapshot; advance(r, 10); expect(r.snapshot).toEqual(s);
    expect(r.events.filter((e) => e.t === 'incident')).toHaveLength(1);
    r.holdStart('right'); expect(r.snapshot.mode).toBe('recovering');
    expect([r.snapshot.x, r.snapshot.y, r.snapshot.z]).toEqual([s.x, s.y, s.z]);
    advance(r, 0.1); expect(r.snapshot.z).toBe(s.z); expect(r.snapshot.y).toBeGreaterThan(s.y);
  });
  it('preserves the rope through a pause and permits regripping', () => {
    const r = new ChaseRunner(); r.holdStart('right'); advance(r, 0.4);
    const s = r.snapshot; r.pauseHold(); r.holdStart('left');
    expect(r.snapshot.anchor).toEqual(s.anchor); expect(r.snapshot.swings).toBe(1);
    r.cancelHold(); expect(r.snapshot.lastRelease).toBe('cancel');
  });
  it('sweeps collisions in 3D, rejecting passes beside or above the box', () => {
    const e = CHASE.entities[0]!;
    expect(hits3({ ...e, z: e.z - 20 }, { ...e, z: e.z + 20 }, e)).toBe(true);
    expect(hits3({ ...e, x: e.x + 4, z: e.z - 20 }, { ...e, x: e.x + 4, z: e.z + 20 }, e)).toBe(false);
    expect(hits3({ ...e, y: e.y + 4, z: e.z - 20 }, { ...e, y: e.y + 4, z: e.z + 20 }, e)).toBe(false);
  });
  it('is deterministic across equivalent update batches', () => {
    const a = new ChaseRunner(), b = new ChaseRunner(); a.holdStart('left'); b.holdStart('left');
    for (let i = 0; i < 60; i++) a.update(1 / 60);
    for (let i = 0; i < 30; i++) b.update(1 / 30);
    expect(a.snapshot).toEqual(b.snapshot);
  });
  it('later releases make the two higher gifts reachable without recovery', () => {
    const r = new ChaseRunner(); let side: Side = 'left'; r.holdStart(side);
    for (let i = 0; i < 3600 && !r.snapshot.complete; i++) {
      const s = r.snapshot;
      if (s.requiresRelease || (s.anchor && s.z > s.anchor.z + s.radius * 0.79)) {
        r.holdEnd(); side = side === 'left' ? 'right' : 'left';
      } else if (!s.held && s.targets[side]) r.holdStart(side);
      r.update(1 / 60);
    }
    expect(r.snapshot.complete).toBe(true);
    expect(r.snapshot.recoveries).toBe(0);
    expect(r.entityStates.get('g2')).toBe('collected');
    expect(r.entityStates.get('g4')).toBe('collected');
  });
  it('can traverse the short course by alternating sides with ordinary releases', () => {
    const r = new ChaseRunner(); let side: Side = 'left'; r.holdStart(side);
    let minX = 0, maxX = 0;
    for (let i = 0; i < 60 * 90 && !r.snapshot.complete; i++) {
      const s = r.snapshot;
      minX = Math.min(minX, s.x); maxX = Math.max(maxX, s.x);
      if (s.requiresRelease || (s.anchor && s.mode === 'swinging' && s.z > s.anchor.z + s.radius * 0.65)) {
        r.holdEnd(); side = side === 'left' ? 'right' : 'left';
      } else if (!s.held && (s.targets[side] || s.mode === 'recovery')) r.holdStart(side);
      r.update(1 / 60);
    }
    expect(r.snapshot.complete).toBe(true);
    expect(minX).toBeLessThan(-1); expect(maxX).toBeGreaterThan(1);
    expect(r.snapshot.recoveries).toBeLessThanOrEqual(2);
    expect(r.events.filter((e) => e.t === 'routeComplete')).toHaveLength(1);
    expect(r.entityStates.get('teach')).toBe('collected');
    expect(r.events.filter((e) => e.t === 'gift').length).toBeGreaterThanOrEqual(2);
  });
});
