// @vitest-environment jsdom
import { afterEach, beforeEach, expect, it } from 'vitest';
import { ChaseInput } from '../src/core/chase-input';

let surface: HTMLElement, input: ChaseInput;
let events: { type: string; side?: string }[];
function pointer(type: string, x: number, id = 1): void {
  const event = new Event(type, { bubbles: true, cancelable: true });
  Object.defineProperties(event, { clientX: { value: x }, pointerId: { value: id }, button: { value: 0 } });
  surface.dispatchEvent(event);
}
function key(type: string, code: string, repeat = false): void {
  window.dispatchEvent(new KeyboardEvent(type, { code, repeat, cancelable: true }));
}
beforeEach(() => {
  document.body.innerHTML = '<div id="surface"></div>';
  surface = document.getElementById('surface')!;
  surface.getBoundingClientRect = () => ({ left: 400, width: 400 }) as DOMRect;
  Object.assign(surface, { setPointerCapture() {}, hasPointerCapture: () => false });
  events = []; input = new ChaseInput(surface); input.onGesture((g) => events.push(g)); input.attach();
});
afterEach(() => input.detach());
it('uses the playfield midpoint and latches the side until release', () => {
  pointer('pointerdown', 450); pointer('pointermove', 750); pointer('pointerup', 750);
  pointer('pointerdown', 750); pointer('pointerup', 450);
  expect(events).toEqual([{ type: 'holdStart', side: 'left' }, { type: 'holdEnd' }, { type: 'holdStart', side: 'right' }, { type: 'holdEnd' }]);
});
it('ignores a second finger and its release', () => {
  pointer('pointerdown', 450, 1); pointer('pointerdown', 750, 2); pointer('pointerup', 750, 2);
  expect(events).toHaveLength(1); pointer('pointerup', 450, 1); expect(events).toHaveLength(2);
});
it('cancels once when pointer capture is lost', () => {
  pointer('pointerdown', 750); pointer('lostpointercapture', 750); pointer('pointercancel', 750); pointer('pointerup', 750);
  expect(events).toEqual([{ type: 'holdStart', side: 'right' }, { type: 'holdCancel' }]);
});
it('does not let repeated or opposite keyboard presses replace a live hold', () => {
  key('keydown', 'KeyA'); key('keydown', 'KeyA', true); key('keydown', 'KeyD'); key('keyup', 'KeyD');
  expect(events).toHaveLength(1); key('keyup', 'KeyA'); key('keydown', 'ArrowRight'); key('keyup', 'ArrowRight');
  expect(events.map((e) => e.type)).toEqual(['holdStart', 'holdEnd', 'holdStart', 'holdEnd']);
  expect(events[2]?.side).toBe('right');
});
it('clearing a paused hold ignores the stale release and accepts a fresh press', () => {
  key('keydown', 'KeyA'); input.clearHeld(); key('keyup', 'KeyA');
  expect(events).toHaveLength(1); key('keydown', 'KeyD'); expect(events[1]?.side).toBe('right');
});
