import { describe, expect, it } from 'vitest';
import { SwingRunner, segmentHitsBox } from '../src/levels/swing';
import { LEVEL_2_PRACTICE } from '../src/levels/level2';
import type { SwingConfig } from '../src/levels/swing-types';
import { STEP_S } from '../src/core/loop';
import { scoreRun } from '../src/core/scoring';

const config = (over: Partial<SwingConfig> = {}): SwingConfig => ({ ...LEVEL_2_PRACTICE, entities: [], ...over });
function until(r: SwingRunner, predicate: () => boolean, max = 20_000): void {
  for (let i = 0; i < max && !predicate(); i++) r.update(STEP_S);
  expect(predicate(), 'simulation reached the requested state').toBe(true);
}

describe('attachment and input state', () => {
  it('attaches to the highlighted reachable anchor without moving the player', () => {
    const r = new SwingRunner(config());
    const before = r.snapshot;
    expect(before.eligible).not.toBeNull();
    r.holdStart();
    const after = r.snapshot;
    expect(after.anchor?.id).toBe(before.eligible?.id);
    expect(after.z).toBe(before.z);
    expect(after.y).toBe(before.y);
    expect(after.radius).toBeCloseTo(Math.hypot(after.z - after.anchor!.z, after.y - after.anchor!.y), 10);
    expect(after.radius).toBeLessThanOrEqual(config().maxRope);
  });

  it('arms a held press outside a window, then catches when one opens', () => {
    const r = new SwingRunner(config({ anchors: [{ id: 'later', z: 21, y: 12 }] }));
    r.holdStart();
    expect(r.snapshot.mode).toBe('armed');
    until(r, () => r.snapshot.mode === 'swinging');
    expect(r.snapshot.anchor?.id).toBe('later');
  });

  it('rejects anchors whose height or rope length makes them unreachable', () => {
    const r = new SwingRunner(config({ floor: 0, anchors: [
      { id: 'far', z: 7, y: 40 }, { id: 'below', z: 7, y: 4 },
      { id: 'floor-crossing', z: 10, y: 6 },
    ] }));
    expect(r.snapshot.eligible).toBeNull();
    r.holdStart();
    expect(r.snapshot.mode).toBe('armed');
  });

  it('preserves the tangent on manual release and needs a new press', () => {
    const r = new SwingRunner(config());
    r.holdStart();
    for (let i = 0; i < 20; i++) r.update(STEP_S);
    const before = r.snapshot;
    r.holdEnd();
    expect(r.snapshot.anchor).toBeNull();
    expect(r.snapshot.mode).toBe('ballistic');
    expect(r.snapshot.vz).toBe(before.vz);
    expect(r.snapshot.vy).toBe(before.vy);
    expect(r.snapshot.z).toBe(before.z);
    expect(r.snapshot.y).toBe(before.y);
    expect(r.snapshot.held).toBe(false);
    expect(r.snapshot.lastRelease).toBe('manual');
  });

  it('auto-releases upward and cannot chain while the same press is held', () => {
    const r = new SwingRunner(config());
    r.holdStart();
    until(r, () => r.snapshot.releases === 1);
    expect(r.snapshot.lastRelease).toBe('auto');
    expect(r.snapshot.vy).toBeGreaterThan(0);
    expect(r.snapshot.y).toBeGreaterThan(config().floor);
    expect(r.snapshot.requiresRelease).toBe(true);
    for (let i = 0; i < 20; i++) { r.holdStart(); r.update(STEP_S); }
    expect(r.snapshot.swings).toBe(1);
    r.holdEnd();
    r.holdStart();
    until(r, () => r.snapshot.swings === 2);
  });

  it('pauses an attached hold without dropping its rope or momentum', () => {
    const r = new SwingRunner(config());
    r.holdStart(); r.update(0.2);
    const before = r.snapshot;
    r.pauseHold();
    expect(r.snapshot.held).toBe(false);
    expect(r.snapshot.anchor).toEqual(before.anchor);
    expect(r.snapshot.z).toBe(before.z);
    expect(r.snapshot.y).toBe(before.y);
    expect(r.snapshot.vz).toBe(before.vz);
    r.holdStart();
    expect(r.snapshot.swings).toBe(1);
    r.update(STEP_S);
    expect(r.snapshot.mode).toBe('swinging');
  });

  it('pointer cancellation clears the hold and releases exactly once', () => {
    const r = new SwingRunner(config());
    r.holdStart(); r.cancelHold(); r.cancelHold();
    expect(r.snapshot.releases).toBe(1);
    expect(r.snapshot.held).toBe(false);
    expect(r.snapshot.requiresRelease).toBe(false);
  });
});

describe('pendulum and assisted travel', () => {
  it('conserves rope length while gravity trades height for speed', () => {
    const r = new SwingRunner(config({ minAttachSpeed: 20, minSwingSpeed: 0, maxSwingSpeed: 100 }));
    r.holdStart();
    const initial = r.snapshot;
    const initialEnergy = initial.speed ** 2 / 2 + config().gravity * initial.y;
    let fastest = initial.speed;
    let energyError = 0;
    until(r, () => {
      const s = r.snapshot;
      if (s.anchor) {
        expect(Math.hypot(s.z - s.anchor.z, s.y - s.anchor.y)).toBeCloseTo(s.radius, 9);
        fastest = Math.max(fastest, s.speed);
        energyError = Math.max(energyError, Math.abs(s.speed ** 2 / 2 + config().gravity * s.y - initialEnergy));
      }
      return s.releases > 0;
    });
    expect(fastest).toBeGreaterThan(initial.speed + 1);
    expect(energyError / initialEnergy).toBeLessThan(0.01);
  });

  it('bounds the whole swing above the floor, even with an unending hold', () => {
    const r = new SwingRunner(config());
    r.holdStart();
    let minY = Infinity;
    until(r, () => {
      if (r.snapshot.anchor) minY = Math.min(minY, r.snapshot.y);
      return r.snapshot.releases > 0;
    });
    expect(minY).toBeGreaterThanOrEqual(config().floor + 1.2);
    expect(r.snapshot.swings).toBe(1);
  });

  it('stops completely on a fall and waits indefinitely for a fresh hold', () => {
    const r = new SwingRunner(config());
    until(r, () => r.isFrozen);
    expect(r.snapshot.y).toBe(config().floor);
    expect(r.snapshot.vz).toBe(0);
    expect(r.snapshot.vy).toBe(0);
    expect(r.snapshot.eligible).not.toBeNull();
    const before = r.snapshot;
    r.update(100);
    expect(r.snapshot).toEqual(before);
    expect(r.events).toEqual([{ t: 'incident', level: 2 }]);
    r.holdStart();
    expect(r.snapshot.mode).toBe('recovering');
    expect(r.snapshot.z).toBe(before.z);
    expect(r.snapshot.y).toBe(before.y);
    r.update(0.1);
    expect(r.snapshot.z).toBe(before.z);
    until(r, () => r.snapshot.mode === 'swinging');
    expect(r.snapshot.y).toBeGreaterThan(before.y);
    expect(r.snapshot.z - before.z).toBeLessThan(config().maxSwingSpeed * STEP_S);
    expect(r.events).toHaveLength(1);
  });

  it('keeps many chained swings finite, forward, within the envelope and capped', () => {
    const r = new SwingRunner(config());
    let previousZ = 0;
    until(r, () => {
      const s = r.snapshot;
      if (s.mode === 'recovery') { r.holdEnd(); r.holdStart(); }
      else if (s.mode === 'swinging' && s.angle > Math.PI * 55 / 180) r.holdEnd();
      else if (!s.held && s.eligible) r.holdStart();
      expect(Number.isFinite(s.z + s.y + s.vz + s.vy)).toBe(true);
      expect(s.z).toBeGreaterThanOrEqual(previousZ - 1e-8);
      expect(s.y).toBeGreaterThanOrEqual(config().floor);
      expect(s.y).toBeLessThanOrEqual(config().ceiling);
      if (s.anchor) expect(s.speed).toBeLessThanOrEqual(config().maxSwingSpeed + 1e-8);
      previousZ = s.z;
      return s.complete;
    });
    expect(r.snapshot.swings).toBeGreaterThan(20);
    expect(r.snapshot.lastCycle).toBeGreaterThan(0);
    expect(r.events.filter((e) => e.t === 'routeComplete')).toEqual([{ t: 'routeComplete', level: 2 }]);
    const before = r.snapshot;
    r.holdStart(); r.holdEnd(); r.update(10);
    expect(r.snapshot).toEqual(before);
  });

  it('is deterministic across frame batches of the same fixed substeps', () => {
    const a = new SwingRunner(config());
    const b = new SwingRunner(config());
    a.holdStart(); b.holdStart();
    for (let i = 0; i < 120; i++) a.update(1 / 60);
    for (let i = 0; i < 60; i++) b.update(1 / 30);
    expect(a.snapshot.z).toBeCloseTo(b.snapshot.z, 8);
    expect(a.snapshot.y).toBeCloseTo(b.snapshot.y, 8);
  });
});

describe('swept two dimensional collision and rescue', () => {
  it('catches a crossed box and rejects a height miss or parallel near miss', () => {
    const box = { z: 100, y: 5 };
    expect(segmentHitsBox({ z: 0, y: 5 }, { z: 200, y: 5 }, box, 1, 1)).toBe(true);
    expect(segmentHitsBox({ z: 0, y: 9 }, { z: 200, y: 9 }, box, 1, 1)).toBe(false);
    expect(segmentHitsBox({ z: 98, y: 0 }, { z: 98, y: 10 }, box, 1, 1)).toBe(false);
    expect(segmentHitsBox({ z: 100, y: 0 }, { z: 100, y: 10 }, box, 1, 1)).toBe(true);
  });

  it.each([40, 120])('registers gifts and hazards at %s u/s without duplicate events', (speed) => {
    const r = new SwingRunner(config({
      routeLength: 200, gravity: 0, anchors: [],
      forwardFloor: speed, forwardCeiling: speed,
      entities: [
        { id: 'g', z: 50, y: 5, kind: 'gift', scored: true, halfZ: 0.1, halfY: 0.5 },
        { id: 'h', z: 100, y: 5, kind: 'hazard', scored: false, halfZ: 0.1, halfY: 0.5 },
      ],
    }));
    until(r, () => r.isFrozen);
    r.holdStart();
    until(r, () => r.snapshot.complete);
    expect(r.events.filter((e) => e.t === 'gift')).toEqual([{ t: 'gift', level: 2 }]);
    expect(r.events.filter((e) => e.t === 'incident')).toEqual([{ t: 'incident', level: 2 }]);
    expect(scoreRun(r.events).levelScores[1]).toBe(250);
  });

  it('freezes at a collision and cannot charge again while waiting or recovering', () => {
    const r = new SwingRunner(config({
      routeLength: 500, start: { z: 0, y: 40 }, ceiling: 50, anchors: [],
      entities: [{ id: 'h', z: 1, y: 40, kind: 'hazard', scored: false, halfZ: 0.5, halfY: 1 }],
    }));
    until(r, () => r.isFrozen);
    const frozen = r.snapshot;
    r.update(100);
    expect(r.snapshot).toEqual(frozen);
    expect(r.snapshot.failure).toBe('hazard');
    r.holdStart(); r.update(0.5);
    expect(r.events.filter((e) => e.t === 'incident')).toHaveLength(1);
  });

  it('does not move or resolve upcoming gifts during frozen recovery or its vertical lift', () => {
    const r = new SwingRunner(config({
      start: { z: 0, y: -11.95 }, anchors: [],
      entities: [{ id: 'g', z: 8, y: 4, kind: 'gift', scored: true, halfZ: 0.5, halfY: 0.5 }],
    }));
    until(r, () => r.isFrozen);
    const z = r.snapshot.z;
    r.update(100);
    expect(r.entityStates.has('g')).toBe(false);
    r.holdStart();
    until(r, () => r.snapshot.mode === 'swinging');
    expect(r.snapshot.z - z).toBeLessThan(config().maxSwingSpeed * STEP_S);
    expect(r.entityStates.has('g')).toBe(false);
    expect(r.events.some((e) => e.t === 'gift')).toBe(false);
  });

  it('requires lifting the old press before recovering from a held-input fall', () => {
    const r = new SwingRunner(config());
    r.holdStart();
    until(r, () => r.isFrozen);
    expect(r.snapshot.requiresRelease).toBe(true);
    r.holdStart(); r.update(1);
    expect(r.isFrozen).toBe(true);
    r.holdEnd(); r.holdStart();
    expect(r.snapshot.mode).toBe('recovering');
  });

  it('can always recover even when no normal anchors exist', () => {
    const r = new SwingRunner(config({ anchors: [] }));
    until(r, () => r.isFrozen);
    expect(r.snapshot.eligible?.id).toMatch(/^recovery-/);
    r.holdStart();
    const y = r.snapshot.y;
    r.update(0.1);
    expect(r.snapshot.y).toBeGreaterThan(y);
    r.holdEnd();
    expect(r.snapshot.vy).toBeGreaterThan(0);
  });

  it('permits a fresh recovery grip after app pause clears a held press', () => {
    const r = new SwingRunner(config());
    r.holdStart(); until(r, () => r.isFrozen);
    r.pauseHold(); r.holdStart();
    expect(r.snapshot.mode).toBe('recovering');
  });
});

describe('authored review route', () => {
  it('has spacious anchors and exactly four scored gifts, one teaching gift and four hazards', () => {
    const c = LEVEL_2_PRACTICE;
    for (let i = 1; i < c.anchors.length; i++) {
      const gap = c.anchors[i]!.z - c.anchors[i - 1]!.z;
      expect(gap).toBeGreaterThanOrEqual(24);
      expect(gap).toBeLessThanOrEqual(28);
    }
    expect(c.entities.filter((e) => e.kind === 'gift' && e.scored)).toHaveLength(4);
    expect(c.entities.filter((e) => e.kind === 'gift' && !e.scored)).toHaveLength(1);
    expect(c.entities.filter((e) => e.kind === 'hazard')).toHaveLength(4);
    for (let i = 1; i < c.entities.length; i++) {
      expect((c.entities[i]!.z - c.entities[i - 1]!.z) / c.maxSwingSpeed).toBeGreaterThanOrEqual(1.2);
    }
  });

  it('has a playable path through every gift and obstacle for a full 600-point level', () => {
    const r = new SwingRunner(LEVEL_2_PRACTICE);
    until(r, () => {
      const s = r.snapshot;
      expect(s.mode).not.toBe('recovery');
      if (s.mode === 'swinging' && s.angle >= Math.PI * 55 / 180) r.holdEnd();
      else if (!s.held && s.eligible) r.holdStart();
      return s.complete;
    });
    expect(r.entityStates.get('teach')).toBe('collected');
    expect(r.events.filter((e) => e.t === 'gift')).toHaveLength(4);
    expect(r.snapshot.incidents).toBe(0);
    expect(scoreRun(r.events).levelScores[1]).toBe(600);
  });
});
