/**
 * Render the actual bundled app without opening a listening socket. Playwright
 * fulfills same-origin requests from a local build, useful in the sandbox.
 * Includes real keyboard/touch gestures, pause, replay and projected framing.
 */
import { build } from 'vite';
import { chromium } from 'playwright';
import { mkdirSync, readFileSync, existsSync } from 'node:fs';
import { resolve, extname } from 'node:path';
import assert from 'node:assert/strict';

const OUT = resolve('node_modules/.cache/swing-review');
await build({
  logLevel: 'warn',
  define: { 'import.meta.env.DEV': 'true' },
  build: { outDir: OUT, emptyOutDir: true },
});
mkdirSync('tools/shots', { recursive: true });
const browser = await chromium.launch({ args: [
  '--single-process', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
  // The sandbox cannot allocate macOS IOSurfaces for the compositor. WebGL
  // still runs through SwiftShader with software compositing enabled.
  '--disable-gpu-compositing',
] });
const context = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
const page = await context.newPage();
const errors = [];
const requests = [];
page.on('pageerror', (e) => errors.push(e.message));
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
context.on('request', (r) => requests.push(r.url()));
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.glb': 'model/gltf-binary', '.webp': 'image/webp' };
await context.route('**/*', async (route) => {
  const url = new URL(route.request().url());
  if (url.pathname === '/api/health') {
    return route.fulfill({ json: { ok: true, db: false, detail: 'offline browser check' } });
  }
  const file = resolve(OUT, '.' + (url.pathname === '/' ? '/index.html' : url.pathname));
  if (!file.startsWith(OUT + '/') || !existsSync(file)) return route.fulfill({ status: 404, body: 'Missing local review file' });
  return route.fulfill({ body: readFileSync(file), contentType: mime[extname(file)] ?? 'application/octet-stream' });
});
const state = () => page.evaluate(() => window.__swingReview.snapshot);
const frame = () => page.evaluate(() => window.__swingReview.framing());
const wait = (fn) => page.waitForFunction(fn, null, { timeout: 12_000 });
const visible = (p, margin = 0.96) => p && Math.abs(p[0]) < margin && Math.abs(p[1]) < margin && p[2] < 1;

try {
  await page.clock.install();
  await page.goto('https://swing-review.local/');
  await wait(() => !!window.__swingReview);
  await page.clock.runFor(100);
  assert.equal((await state()).mode, 'ready');
  assert.equal(requests.some((u) => /\/models\//.test(u)), false);
  await page.screenshot({ path: 'tools/shots/level2-3d-ready.png' });
  const cdp = await context.newCDPSession(page);
  const touch = (type, x = 80, y = 440) => cdp.send('Input.dispatchTouchEvent', {
    type, touchPoints: type === 'touchStart' ? [{ x, y }] : [],
  });
  await touch('touchStart');
  assert.equal((await state()).anchor.side, 'left');
  await page.clock.runFor(650);
  assert.ok((await state()).x < -1);
  await page.screenshot({ path: 'tools/shots/level2-3d-left.png' });
  await touch('touchEnd');
  assert.equal((await state()).lastRelease, 'manual');
  await page.keyboard.press('KeyR');
  await touch('touchStart', 310);
  assert.equal((await state()).anchor.side, 'right');
  await page.clock.runFor(650);
  assert.ok((await state()).x > 1);
  await page.screenshot({ path: 'tools/shots/level2-3d-right.png' });
  await touch('touchCancel');
  assert.equal((await state()).lastRelease, 'cancel');

  await page.keyboard.press('KeyR');
  await page.keyboard.down('KeyA');
  await page.clock.runFor(300);
  await page.keyboard.press('KeyP');
  const paused = await state();
  await page.clock.runFor(1000);
  assert.deepEqual(await state(), paused);
  assert.ok(paused.anchor);
  await page.keyboard.up('KeyA');
  await page.keyboard.press('KeyP');
  await page.keyboard.down('KeyA');
  assert.equal((await state()).anchor.id, paused.anchor.id);
  await page.keyboard.up('KeyA');

  // Desktop uses the letterboxed playfield midpoint, not the window midpoint.
  for (const [width, height] of [[375,667], [390,844], [430,932], [280,653], [768,1024], [1280,800]]) {
    await page.setViewportSize({ width, height });
    await page.keyboard.press('KeyR');
    await page.clock.runFor(50);
    let f = await frame();
    assert.ok(visible(f.player), `ready player ${width}: ${f.player}`);
    assert.equal(f.anchors.length, 2);
    for (const a of f.anchors) assert.ok(visible(a), `ready anchor ${width}: ${a}`);
    const rect = await page.locator('#surface').boundingBox();
    await page.mouse.move(rect.x + rect.width * 0.75, rect.y + rect.height * 0.55);
    await page.mouse.down();
    assert.equal((await state()).anchor.side, 'right');
    for (let i = 0; i < 24; i++) {
      await page.clock.runFor(100); f = await frame();
      assert.ok(visible(f.player), `moving player ${width} sample ${i}: ${f.player}`);
      // The selected rope endpoint stays visible throughout the swing.
      if ((await state()).anchor) for (const a of f.anchors) assert.ok(visible(a), `active anchor ${width} sample ${i}: ${a}`);
    }
    await page.mouse.up();
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1), false);
    console.log(`PASS framing and right-side pointer: ${width}x${height}`);
  }

  await page.setViewportSize({ width: 390, height: 844 });
  await page.keyboard.press('KeyR');
  await page.keyboard.press('KeyA');
  await page.clock.runFor(6000);
  const failure = await state();
  assert.equal(failure.mode, 'recovery');
  await page.clock.runFor(2000); assert.deepEqual(await state(), failure);
  await page.screenshot({ path: 'tools/shots/level2-3d-recovery.png' });
  await page.keyboard.down('KeyD');
  assert.equal((await state()).mode, 'recovering');
  assert.equal((await state()).z, failure.z);
  assert.ok(Math.abs((await state()).y - failure.y) <= 0.31, 'no teleport on reattachment (at most one animation frame)');
  await page.clock.runFor(100);
  assert.equal((await state()).z, failure.z);
  assert.ok((await state()).y > failure.y);
  await page.keyboard.up('KeyD');

  await page.keyboard.press('KeyR');
  let side = 'left';
  const key = () => side === 'left' ? 'KeyA' : 'KeyD';
  await page.keyboard.down(key());
  let shot = false, maxDraws = 0, maxTriangles = 0;
  const seen = new Set();
  for (let i = 0; i < 1500 && !(await state()).complete; i++) {
    const s = await state();
    if (s.requiresRelease || (s.mode === 'swinging' && s.z > s.anchor.z + s.radius * 0.65)) {
      await page.keyboard.up(key()); side = side === 'left' ? 'right' : 'left';
    } else if (!s.held && (s.targets[side] || s.mode === 'recovery')) await page.keyboard.down(key());
    const f = await frame();
    maxDraws = Math.max(maxDraws, f.draws); maxTriangles = Math.max(maxTriangles, f.triangles);
    assert.ok(visible(f.player), `route player at ${s.z}: ${f.player}`);
    for (const e of f.entities) if (visible(e.point)) seen.add(e.id);
    if (!shot && s.z > 80) {
      await page.screenshot({ path: 'tools/shots/level2-3d-course.png' }); shot = true;
    }
    await page.clock.runFor(33);
  }
  assert.equal((await state()).complete, true);
  assert.ok((await state()).recoveries <= 2, 'alternating controls should be forgiving');
  assert.ok(Number(await page.locator('#hud-score').textContent()) >= 300, 'gift and completion scoring');
  for (const id of ['teach', 'g1', 'g2', 'g3', 'g4', 'roof', 'bridge']) assert.ok(seen.has(id), `${id} visible ahead`);
  assert.equal(await page.locator('#swing-action').textContent(), 'Course complete');
  console.log('Full route:', { score: await page.locator('#hud-score').textContent(), recoveries: (await state()).recoveries, maxDraws, maxTriangles });
  await page.locator('#btn-replay').click();
  assert.equal((await state()).mode, 'ready');
  assert.equal(await page.locator('#hud-score').textContent(), '0');
  await page.keyboard.down('KeyD');
  await page.evaluate(() => window.dispatchEvent(new Event('blur')));
  assert.equal(await page.evaluate(() => window.__swingReview.paused), true);
  const blurred = await state();
  await page.clock.runFor(500); assert.deepEqual(await state(), blurred);
  await page.keyboard.up('KeyD');

  await page.goto('https://swing-review.local/?level=1&clean&layers=none');
  await page.clock.runFor(600);
  assert.equal(await page.locator('body').getAttribute('data-level'), null);
  assert.equal(await page.locator('#btn-replay').count(), 0);
  assert.match(await page.locator('#debug').textContent(), /stage\s+1\/3/);
  assert.deepEqual(errors, []);
  console.log('PASS 3D left/right touch, cancel, pause, framing, recovery, gifts, full route, replay, and level 1.');
} catch (e) {
  console.error('Browser errors:', errors);
  console.error('State:', await state().catch(() => null));
  await page.screenshot({ path: 'tools/shots/level2-check-failure.png' }).catch(() => {});
  throw e;
} finally { await browser.close(); }

